@dmd-features-service
Feature: DMD Features Service APIs
  All DMDFeatures scenarios for the dmd-features-service microservice.

  Background:
    Given the API name is "dmd-features-service"

  @smoke @DMDFeatures
  Scenario: DMDFeatures - empty appType retrieveDeviceSimInfo scenario 1
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>359324081412299</deviceId><simId>89148000004735113345</simId></requestBody></dmd>" for microservice "dmd-features-service"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response should contain field "//statusCode"
    And  the response message should be "SUCCESS"

  @smoke @DMDFeatures
  Scenario: DMDFeatures - empty appType retrieveDeviceSimInfo scenario 2
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>99000044000074</deviceId><simId>89148000004735113345</simId></requestBody></dmd>" for microservice "dmd-features-service"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response message should be "SUCCESS"

  @smoke @DMDFeatures
  Scenario: DMDFeatures - empty appType deviceId only scenario 3
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>A0000007077057</deviceId></requestBody></dmd>" for microservice "dmd-features-service"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"

  @smoke @DMDFeatures
  Scenario: DMDFeatures - empty appType simId only scenario 4
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><simId>89148000004735113345</simId></requestBody></dmd>" for microservice "dmd-features-service"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"

  @smoke @DMDFeatures
  Scenario: DMDFeatures - NetACE appType POS clientId
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType>NetACE</appType><requestId>sadsadssaf</requestId></requestHeader><clientId>POS</clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>359324081412299</deviceId><simId>89148000004735113345</simId></requestBody></dmd>" for microservice "dmd-features-service"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response message should be "SUCCESS"

  @smoke @DMDFeatures
  Scenario: DMDFeatures - POSBE appType DMDSRVR clientId
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType>POSBE</appType><requestId/></requestHeader><clientId>DMDSRVR</clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>359324081412299</deviceId><simId>89148000004735113345</simId></requestBody></dmd>" for microservice "dmd-features-service"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response message should be "SUCCESS"

  @regression @DMDFeatures
  Scenario: DMDFeatures - empty appType deviceId scenario 6
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>A0000003023FBC</deviceId></requestBody></dmd>" for microservice "dmd-features-service"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"

  @regression @DMDFeatures
  Scenario: DMDFeatures - empty appType deviceId scenario 7
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>353004111394057</deviceId></requestBody></dmd>" for microservice "dmd-features-service"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"

  @dynamic @DMDFeatures
  Scenario Outline: DMDFeatures - dynamic deviceId and simId data-driven
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId><deviceId></deviceId><simId><simId></simId></requestBody></dmd>" for microservice "dmd-features-service"
    And  device ID is "<deviceId>"
    And  SIM ID is "<simId>"
    When the client sends a GET request with parameters
    Then the response should be successful
    And  the DMD status code in response should be "00"

    Examples:
      | deviceId        | simId                |
      | 359324081412299 | 89148000004735113345 |
      | 99000044000074  | 89148000004735113345 |
