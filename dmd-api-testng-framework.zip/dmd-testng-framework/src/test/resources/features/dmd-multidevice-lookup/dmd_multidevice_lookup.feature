@dmd-multidevice-lookup
Feature: DMD MultiDevice Lookup Service APIs
  DMDMultiDeviceLookupAPI tests for the dmd-multidevice-lookup microservice.

  Background:
    Given the API name is "dmd-multidevice-lookup"

  @smoke @DMDMultiDeviceLookupAPI
  Scenario: MultiDeviceLookupAPI - POS client NETACE appType
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDMultiDeviceLookupAPI?xmlreqdoc=<dmd><requestHeader><clientId>POS</clientId><appType>NETACE</appType><requestId>Rahul_24.11</requestId></requestHeader><serviceName>DMDMultiDeviceLookup</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceSim><deviceId>359324081412299</deviceId><simId>89148000004735113345</simId></deviceSim></requestBody></dmd>" for microservice "dmd-multidevice-lookup"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response should contain field "//statusCode"
    And  the response message should be "SUCCESS"

  @regression @DMDMultiDeviceLookupAPI
  Scenario Outline: MultiDeviceLookupAPI - dynamic device and SIM pairs
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDMultiDeviceLookupAPI?xmlreqdoc=<dmd><requestHeader><clientId>POS</clientId><appType>NETACE</appType><requestId>Auto_Test</requestId></requestHeader><serviceName>DMDMultiDeviceLookup</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceSim><deviceId><deviceId></deviceId><simId><simId></simId></deviceSim></requestBody></dmd>" for microservice "dmd-multidevice-lookup"
    And  device ID is "<deviceId>"
    And  SIM ID is "<simId>"
    When the client sends a GET request with parameters
    Then the response should be successful
    And  the DMD status code in response should be "00"

    Examples:
      | deviceId        | simId                |
      | 359324081412299 | 89148000004735113345 |
      | 99000044000074  | 89148000004735113345 |
