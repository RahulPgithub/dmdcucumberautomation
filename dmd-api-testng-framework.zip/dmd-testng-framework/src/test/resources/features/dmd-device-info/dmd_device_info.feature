@dmd-device-info
Feature: DMD Device Info Service APIs
  All APIs belonging to the dmd-device-info microservice.

  Background:
    Given the API name is "dmd-device-info"

  # ── DMDLostStolenNonPayInfo ────────────────────────────────────────────────

  @smoke @DMDLostStolenNonPayInfo
  Scenario: LostStolenNonPayInfo - DVS app type pairLookup by simId
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDLostStolenNonPayInfo?xmlreqdoc=<dmd><requestHeader><appType>DVS</appType><requestId></requestId></requestHeader><clientId>DVS</clientId><serviceName>retrieveLostStolenNonPayInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><simId>89148000002543383696</simId></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response should contain field "//statusCode"
    And  the response should contain field "//message"
    And  the response message should be "SUCCESS"

  @smoke @DMDLostStolenNonPayInfo
  Scenario: LostStolenNonPayInfo - NETACE app type pairLookup by deviceId
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDLostStolenNonPayInfo?xmlreqdoc=<dmd><requestHeader><appType>NETACE</appType><requestId></requestId></requestHeader><clientId>NETACE</clientId><serviceName>lostStolenNonPayInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>990004544871985</deviceId></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response message should be "SUCCESS"

  @regression @DMDLostStolenNonPayInfo
  Scenario: LostStolenNonPayInfo - empty appType pairLookup
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDLostStolenNonPayInfo?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>retrieveLostStolenNonPayInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><simId>89148000002543383696</simId></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"

  # ── DMDBulkDeviceSimLookup ─────────────────────────────────────────────────

  @smoke @DMDBulkDeviceSimLookup
  Scenario: BulkDeviceSimLookup - POS client with device and SIM pair
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDBulkDeviceSimLookup?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId>POS</clientId><serviceName>DMDBulkDeviceSimLookup</serviceName><subserviceName/><requestBody><devicePair><seqNum>1</seqNum><deviceId>359324081412299</deviceId><simId>89148000004735113345</simId></devicePair></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response should contain field "//devicePair"
    And  the response message should be "SUCCESS"

  # ── DMDEquipmentIDXml ──────────────────────────────────────────────────────

  @smoke @DMDEquipmentIDXml
  Scenario: EquipmentIDXml - lookup by deviceID query param
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDEquipmentIDXml?deviceID=A0000003023FD3" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the response body should not be empty
    And  the response should contain XML element "dmd"

  # ── DMDFeaturesLight4G ─────────────────────────────────────────────────────

  @smoke @DMDFeaturesLight4G
  Scenario: FeaturesLight4G - POS client retrieveDeviceSimInfo
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeaturesLight4G?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId>POS</clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>359324081412299</deviceId></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response message should be "SUCCESS"

  # ── DMDMacIDInfo ───────────────────────────────────────────────────────────

  @regression @DMDMacIDInfo
  Scenario: MacIDInfo - macidinfo service lookup
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDMacIDInfo?xmlReq=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>macidinfo</serviceName><subServiceName>macIdInfo</subServiceName><requestBody><macId>00163290D78A</macId></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response status code should be 200
    And  the response body should not be empty

  # ── DMDMACIDLookup ─────────────────────────────────────────────────────────

  @smoke @DMDMACIDLookup
  Scenario: MACIDLookup - lookup by MACID query param
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDMACIDLookup?MACID=00163290D78A" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the response body should not be empty
    And  the response should contain XML element "dmd"

  # ── DMDMultiDevice ─────────────────────────────────────────────────────────

  @smoke @DMDMultiDevice
  Scenario: MultiDevice - multi device lookup with deviceSim pair
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDMultiDevice?xmlReq=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><requestBody><deviceSim><deviceId>99000044000074</deviceId><simId>89148000004735113345</simId></deviceSim></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"

  # ── DMDMultiDeviceFirmwareLookup ───────────────────────────────────────────

  @smoke @DMDMultiDeviceFirmwareLookup
  Scenario: MultiDeviceFirmwareLookup - ITAGW firmware info
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDMultiDeviceFirmwareLookup?xmlReq=<dmd><requestHeader><clientId>ITAGW</clientId><appType>ITAGW</appType></requestHeader><serviceName>firmwareInfo</serviceName><requestBody><deviceId>359324081412299</deviceId></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"

  # ── DMDMultiDeviceSimValidation ────────────────────────────────────────────

  @smoke @DMDMultiDeviceSimValidation
  Scenario: MultiDeviceSimValidation - DVS app type
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDMultiDeviceSimValidation?xmlreqdoc=<dmd><requestHeader><appType>DVS</appType><requestId>Rahul_24.11</requestId></requestHeader><requestBody><featureAndDaccAnalysis>false</featureAndDaccAnalysis><deviceSim><deviceId>359324081412299</deviceId><simId>89148000004735113345</simId></deviceSim></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response message should be "SUCCESS"

  # ── DMDMultiDeviceValidation ───────────────────────────────────────────────

  @smoke @DMDMultiDeviceValidation
  Scenario: MultiDeviceValidation - standard validation
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDMultiDeviceValidation?xmlReq=<dmd><requestHeader><appType/><requestId/></requestHeader><clientId/><serviceName>DMDMultiDeviceValidation</serviceName><subServiceName/><requestBody><deviceId>359324081412299</deviceId><simId>89148000004735113345</simId></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"

  # ── DMDMultiMakeModel ──────────────────────────────────────────────────────

  @smoke @DMDMultiMakeModel
  Scenario Outline: MultiMakeModel - multiple deviceID lookup
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDMultiMakeModel?deviceID=<deviceIDs>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the response body should not be empty
    And  the response should contain XML element "dmd"

    Examples:
      | deviceIDs                                    |
      | A0000007077057,A0000007077058,A0000007077059 |
      | A0000003023F9A,99000044000076,14112648436    |

  # ── DMDScmplus ─────────────────────────────────────────────────────────────

  @smoke @DMDScmplus
  Scenario: Scmplus - lookup by meid
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDScmplus?meid=99000044000090" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the response body should not be empty
    And  the response should contain XML element "dmd"

  # ── DMDXml ─────────────────────────────────────────────────────────────────

  @smoke @DMDXml
  Scenario: DMDXml - featuresLight CCES action
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDXml?app_type=CCES&action=featuresLight&deviceID=A0000003023FBC" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the response should contain XML element "dmd"

  # ── DMDDeviceMacIdService ──────────────────────────────────────────────────

  @smoke @DMDDeviceMacIdService
  Scenario: DeviceMacIdService - MVD client retrieveMacIdforDevice
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDDeviceMacIdService?xmlreqdoc=<dmd><requestHeader><appType>MVD</appType><requestId></requestId><clientId>MVD</clientId><serviceName>retrieveMacIdforDevice</serviceName></requestHeader><requestBody><deviceId>359324081412299</deviceId></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"

  # ── DMDDeviceProdID ────────────────────────────────────────────────────────

  @smoke @DMDDeviceProdID
  Scenario: DeviceProdID - standard prod ID lookup
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDDeviceProdID?xmlReq=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><requestBody><CLIENT_NAME></CLIENT_NAME><APL_NAME></APL_NAME><deviceId>359324081412299</deviceId></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"

  # ── DMDDeviceSimPairLookup ─────────────────────────────────────────────────

  @smoke @DMDDeviceSimPairLookup
  Scenario: DeviceSimPairLookup - MYBUSINESS app type
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDDeviceSimPairLookup?xmlReq=<dmd><requestHeader><appType>MYBUSINESS</appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>DMD-retrieveDeviceSimPairInfo</serviceName><requestBody><deviceId>359324081412299</deviceId></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"

  # ── DMDRM ──────────────────────────────────────────────────────────────────

  @smoke @DMDRM
  Scenario: DMDRM - app_type param lookup
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDRM?app_type=app_type&deviceID=353004111394057" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the response body should not be empty

  # ── DMDDeviceWarrantyVendorService ─────────────────────────────────────────

  @smoke @DMDDeviceWarrantyVendorService
  Scenario: DeviceWarrantyVendorService - NETACE warranty lookup
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDDeviceWarrantyVendorService?xmlReq=<dmd><requestHeader><appType>NETACE</appType><requestId>ESQA4pos:vipm2msvc01:01:1600068738990</requestId></requestHeader><clientId>NETACE</clientId><serviceName>getWarrantyVendor</serviceName><requestBody><deviceId>359324081412299</deviceId></requestBody></dmd>" for microservice "dmd-device-info"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response message should be "SUCCESS"
