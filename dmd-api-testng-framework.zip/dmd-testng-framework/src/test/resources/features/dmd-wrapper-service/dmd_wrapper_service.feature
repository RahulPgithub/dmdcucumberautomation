@dmd-wrapper-service
Feature: DMD Wrapper Service APIs
  DMDDaccSaccCompatibility and DMDSaccDaccCompatibility for dmd-wrapper-service.

  Background:
    Given the API name is "dmd-wrapper-service"

  # ── DMDDaccSaccCompatibility ───────────────────────────────────────────────

  @smoke @DMDDaccSaccCompatibility
  Scenario: DaccSaccCompatibility - DACC to SACC lookup
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDDaccSaccCompatibility?dacc=00929" for microservice "dmd-wrapper-service"
    When the client sends a GET request
    Then the response should be successful
    And  the response body should not be empty
    And  the response should contain XML element "dmd"

  @regression @DMDDaccSaccCompatibility
  Scenario Outline: DaccSaccCompatibility - multiple DACC values
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDDaccSaccCompatibility?dacc=<dacc>" for microservice "dmd-wrapper-service"
    When the client sends a GET request
    Then the response should be successful
    And  the response body should not be empty

    Examples:
      | dacc  |
      | 00929 |
      | 00930 |

  # ── DMDSaccDaccCompatibility ───────────────────────────────────────────────

  @smoke @DMDSaccDaccCompatibility
  Scenario: SaccDaccCompatibility - SACC to DACC lookup
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDSaccDaccCompatibility?sacc=00607" for microservice "dmd-wrapper-service"
    When the client sends a GET request
    Then the response should be successful
    And  the response body should not be empty
    And  the response should contain XML element "dmd"

  @regression @DMDSaccDaccCompatibility
  Scenario Outline: SaccDaccCompatibility - multiple SACC values
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDSaccDaccCompatibility?sacc=<sacc>" for microservice "dmd-wrapper-service"
    When the client sends a GET request
    Then the response should be successful
    And  the response body should not be empty

    Examples:
      | sacc  |
      | 00607 |
      | 00608 |
