@dmd-data-service
Feature: DMD Data Service APIs
  All APIs belonging to the dmd-data-service microservice.

  Background:
    Given the API name is "dmd-data-service"

  # ── DMDB2BMacidLookup ──────────────────────────────────────────────────────

  @smoke @DMDB2BMacidLookup
  Scenario: B2BMacidLookup - DVS DEVICE_SCAN b2bmacId lookup
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDB2BMacidLookup?xmlReq=<dmd><requestHeader><requestId/><clientId>DVS</clientId><requestType>DEVICE_SCAN</requestType><requestApplication>Retail</requestApplication><userId/></requestHeader><requestBody><serviceName>DMDB2BMacidLookup</serviceName><b2bmacId>003044342CFC</b2bmacId></requestBody></dmd>" for microservice "dmd-data-service"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response should contain field "//statusCode"
    And  the response should contain field "//message"
    And  the response message should be "SUCCESS"

  # ── DMDModelSummary ────────────────────────────────────────────────────────

  @smoke @DMDModelSummary
  Scenario: ModelSummary - WFM app type device model
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDModelSummary?app_type=WFM&deviceId=6912615731" for microservice "dmd-data-service"
    When the client sends a GET request
    Then the response should be successful
    And  the response body should not be empty
    And  the response should contain XML element "dmd"

  @regression @DMDModelSummary
  Scenario Outline: ModelSummary - parameterized app_type and deviceId
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDModelSummary?app_type=<appType>&deviceId=<deviceId>" for microservice "dmd-data-service"
    When the client sends a GET request
    Then the response should be successful
    And  the response body should not be empty

    Examples:
      | appType | deviceId   |
      | WFM     | 6912615731 |
      | DVS     | 6912615731 |

  # ── DMDNegativeCheck ───────────────────────────────────────────────────────

  @smoke @DMDNegativeCheck
  Scenario: NegativeCheck - DVS device negative check
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDNegativeCheck?xmlReq=<dmd><requestHeader><appType>DVS</appType><requestId></requestId></requestHeader><requestBody><deviceId>A00000231FD3EC</deviceId><deviceType>MEID</deviceType></requestBody></dmd>" for microservice "dmd-data-service"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response message should be "SUCCESS"

  # ── DMDReadDeviceDetails ───────────────────────────────────────────────────

  @smoke @DMDReadDeviceDetails
  Scenario: ReadDeviceDetails - DVS DEVICE_SCAN read details
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDReadDeviceDetails?xmlreqdoc=<dmd><requestHeader><requestId/><clientId>DVS</clientId><requestType>DEVICE_SCAN</requestType><requestApplication>Retail</requestApplication><userId/></requestHeader><requestBody><serviceName>DMDReadDeviceDetails</serviceName><deviceId>359324081412299</deviceId></requestBody></dmd>" for microservice "dmd-data-service"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response should contain field "//statusCode"
    And  the response message should be "SUCCESS"

  # ── DMDSIMCompatibility ────────────────────────────────────────────────────

  @smoke @DMDSIMCompatibility
  Scenario: SIMCompatibility - check SIM compat for device
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDSIMCompatibility?deviceId=35611609009749" for microservice "dmd-data-service"
    When the client sends a GET request
    Then the response should be successful
    And  the response body should not be empty
    And  the response should contain XML element "dmd"

  # ── DMDDeviceCompare ───────────────────────────────────────────────────────

  @smoke @DMDDeviceCompare
  Scenario: DeviceCompare - compare by XML request
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDDeviceCompare?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>DMDDeviceCompare</serviceName><requestBody><deviceId>35241109213316</deviceId></requestBody></dmd>" for microservice "dmd-data-service"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
    And  the response message should be "SUCCESS"

  @regression @DMDDeviceCompare
  Scenario: DeviceCompare - compare using deviceSku
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDDeviceCompare?xmlreqdoc=<dmd><requestBody><deviceId>35241109213316</deviceId><deviceSku>SMG965UZKV</deviceSku></requestBody></dmd>" for microservice "dmd-data-service"
    When the client sends a GET request
    Then the response should be successful
    And  the DMD status code in response should be "00"
