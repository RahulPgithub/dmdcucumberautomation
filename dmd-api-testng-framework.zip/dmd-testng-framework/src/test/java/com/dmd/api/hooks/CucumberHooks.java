package com.dmd.api.hooks;

import com.dmd.api.config.EnvironmentConfig;
import com.dmd.api.model.ScenarioContext;
import com.dmd.api.utils.EmailReporter;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Cucumber lifecycle hooks integrated with TestNG.
 *
 * ┌─────────────────────────────────────────────────────────────────────┐
 * │  TestNG vs JUnit differences in this class:                         │
 * │                                                                     │
 * │  JUnit version used:  @AfterAll (static)                            │
 * │  TestNG version uses: @AfterSuite via TestNGSuiteListener            │
 * │                       (see listeners/TestNGSuiteListener.java)      │
 * │                                                                     │
 * │  Cucumber @Before / @After remain the same — they are Cucumber      │
 * │  annotations, not JUnit/TestNG ones, so they work identically.      │
 * └─────────────────────────────────────────────────────────────────────┘
 */
@Slf4j
public class CucumberHooks {

    // Shared counters — incremented by every scenario across all runners
    static final AtomicInteger passed  = new AtomicInteger(0);
    static final AtomicInteger failed  = new AtomicInteger(0);
    static final AtomicInteger skipped = new AtomicInteger(0);

    private final ScenarioContext ctx;

    // PicoContainer injects the per-scenario context
    public CucumberHooks(ScenarioContext ctx) {
        this.ctx = ctx;
    }

    // ─── Cucumber lifecycle ───────────────────────────────────────────────

    @Before
    public void beforeScenario(Scenario scenario) {
        log.info("▶ START  [{}] {}", scenario.getId(), scenario.getName());
        // Reset per-scenario state
        ctx.setCurrentResponse(null);
        ctx.setCurrentUrl(null);
        ctx.setDeviceId(null);
        ctx.setSimId(null);
        ctx.setMacId(null);
        ctx.setMeid(null);
        ctx.setAppType(null);
        ctx.setClientId(null);
    }

    @After
    public void afterScenario(Scenario scenario) {
        if (scenario.isFailed()) {
            failed.incrementAndGet();
            // Attach response body to Extent report on failure
            if (ctx.getCurrentResponse() != null) {
                String body = ctx.getCurrentResponse().getBody().asString();
                scenario.attach(body.getBytes(), "text/xml", "Response Body on Failure");
            }
            log.error("✗ FAILED [{}]", scenario.getName());
        } else {
            passed.incrementAndGet();
            log.info("✓ PASSED [{}]", scenario.getName());
        }
    }

    // ─── Suite-level teardown is in TestNGSuiteListener ──────────────────
    //
    // TestNG's @AfterSuite cannot live in a Cucumber glue class.
    // The listener pattern is the correct TestNG equivalent of JUnit's @AfterAll.
    // See: com.dmd.api.listeners.TestNGSuiteListener
}
