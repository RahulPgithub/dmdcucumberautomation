package com.dmd.api.listeners;

import com.dmd.api.config.EnvironmentConfig;
import com.dmd.api.hooks.CucumberHooks;
import com.dmd.api.utils.EmailReporter;
import lombok.extern.slf4j.Slf4j;
import org.testng.ISuite;
import org.testng.ISuiteListener;

/**
 * TestNG ISuiteListener — the TestNG equivalent of JUnit 5's {@code @AfterAll}.
 *
 * Registered in every testng-suites/*.xml via:
 * {@code <listener class-name="com.dmd.api.listeners.TestNGSuiteListener"/>}
 *
 * Responsibilities:
 *  - Log suite start with environment + microservice info
 *  - After the entire suite: print summary banner + send email report
 *
 * Note: scenario counts come from {@link CucumberHooks} static AtomicIntegers
 * because TestNG's own pass/fail counts don't map 1-to-1 with Cucumber scenarios
 * (each scenario is a TestNG "method" call from the DataProvider).
 */
@Slf4j
public class TestNGSuiteListener implements ISuiteListener {

    @Override
    public void onStart(ISuite suite) {
        EnvironmentConfig cfg = EnvironmentConfig.get();
        log.info("╔══════════════════════════════════════════════════════╗");
        log.info("  DMD API Suite Starting");
        log.info("  Suite       : {}", suite.getName());
        log.info("  Environment : {}", cfg.getEnv().toUpperCase());
        log.info("  Microservice: {}", cfg.getMicroservice());
        log.info("  Base URL    : {}", cfg.getBaseUrl());
        log.info("╚══════════════════════════════════════════════════════╝");
    }

    @Override
    public void onFinish(ISuite suite) {
        int p = CucumberHooks.passed.get();
        int f = CucumberHooks.failed.get();
        int s = CucumberHooks.skipped.get();
        int total = p + f + s;

        log.info("╔══════════════════════════════════════════════════════╗");
        log.info("  DMD API Suite Finished");
        log.info("  Suite   : {}", suite.getName());
        log.info("  Total   : {}  |  Passed: {}  |  Failed: {}  |  Skipped: {}", total, p, f, s);
        log.info("  Pass Rate: {}%", total > 0 ? String.format("%.1f", p * 100.0 / total) : "N/A");
        log.info("  Report  : target/extent-reports/SparkReport/index.html");
        log.info("╚══════════════════════════════════════════════════════╝");

        EnvironmentConfig cfg = EnvironmentConfig.get();
        try {
            EmailReporter.sendReport(
                cfg.getEnv(),
                cfg.getMicroservice(),
                total, p, f, s
            );
        } catch (Exception e) {
            log.warn("Email report could not be sent: {}", e.getMessage());
        }
    }
}
