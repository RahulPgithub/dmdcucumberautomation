package com.dmd.api.model;

import io.restassured.response.Response;
import lombok.Data;

/**
 * Shared state injected between step-definition classes via Cucumber PicoContainer.
 * A fresh instance is created for every scenario — no cross-scenario leakage.
 */
@Data
public class ScenarioContext {

    private String   currentUrl;
    private Response currentResponse;
    private String   currentApiName;
    private String   currentMicroservice;

    // Dynamic data fields used in Scenario Outline / DataProvider tests
    private String deviceId;
    private String simId;
    private String macId;
    private String meid;
    private String appType;
    private String clientId;
}
