package com.dmd.api.runners;

import io.cucumber.testng.CucumberOptions;

/**
 * TestNG Cucumber runner for the <b>dmd-features-service</b> microservice.
 */
@CucumberOptions(
    features  = "src/test/resources/features/dmd-features-service",
    glue      = {"com.dmd.api.stepdefs", "com.dmd.api.hooks"},
    plugin    = {
        "pretty",
        "json:target/cucumber-reports/dmd-features-service.json",
        "html:target/cucumber-reports/dmd-features-service.html",
        "tech.grasshopper.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
    },
    monochrome = true,
    publish    = false
)
public class FeaturesServiceRunner extends AbstractCucumberRunner {
}
