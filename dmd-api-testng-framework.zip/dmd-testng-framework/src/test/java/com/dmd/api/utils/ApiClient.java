package com.dmd.api.utils;

import com.dmd.api.config.EnvironmentConfig;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;

import static io.restassured.RestAssured.given;

/**
 * Central HTTP client.  Thread-safe singleton wrapping REST Assured.
 */
@Slf4j
public class ApiClient {

    private static final ApiClient INSTANCE = new ApiClient();
    private final RequestSpecification baseSpec;
    private final RestAssuredConfig    raConfig;

    private ApiClient() {
        EnvironmentConfig cfg = EnvironmentConfig.get();
        raConfig = RestAssured.config()
            .httpClient(HttpClientConfig.httpClientConfig()
                .setParam("http.connection.timeout", cfg.getConnectionTimeout())
                .setParam("http.socket.timeout",     cfg.getReadTimeout()));

        baseSpec = new RequestSpecBuilder()
            .setBaseUri(cfg.getBaseUrl())
            .setConfig(raConfig)
            .addFilter(new RequestLoggingFilter())
            .addFilter(new ResponseLoggingFilter())
            .build();

        log.info("ApiClient ready — baseURI: {}", cfg.getBaseUrl());
    }

    public static ApiClient get() { return INSTANCE; }

    /** GET with explicit query params map. */
    public Response get(String path, Map<String, String> queryParams) {
        RequestSpecification spec = given().spec(baseSpec);
        if (queryParams != null && !queryParams.isEmpty()) {
            spec.queryParams(queryParams);
        }
        return spec.when().get(path).then().extract().response();
    }

    /**
     * GET using a fully-qualified URL (query params already embedded).
     * Used when the XML payload is part of the URL (DMD pattern).
     */
    public Response getFromFullUrl(String fullUrl) {
        return given()
            .config(raConfig)
            .filter(new RequestLoggingFilter())
            .filter(new ResponseLoggingFilter())
            .when()
            .get(fullUrl)
            .then()
            .extract()
            .response();
    }
}
