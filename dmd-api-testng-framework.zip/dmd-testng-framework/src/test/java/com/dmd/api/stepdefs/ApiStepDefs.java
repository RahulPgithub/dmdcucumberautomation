package com.dmd.api.stepdefs;

import com.dmd.api.model.ScenarioContext;
import com.dmd.api.utils.ApiClient;
import com.dmd.api.utils.UrlBuilder;
import com.dmd.api.utils.XmlResponseValidator;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * All Cucumber step definitions for DMD API tests.
 *
 * These are pure Cucumber classes — they work identically whether the runner
 * is JUnit 5 or TestNG.  The only change is in the Runner classes.
 *
 * PicoContainer injects {@link ScenarioContext} — a fresh instance per scenario.
 */
@Slf4j
public class ApiStepDefs {

    private final ScenarioContext ctx;

    public ApiStepDefs(ScenarioContext ctx) {
        this.ctx = ctx;
    }

    // ══════════════════════════════════════════════════════════
    //  GIVEN
    // ══════════════════════════════════════════════════════════

    @Given("the API endpoint is {string} for microservice {string}")
    public void setApiEndpoint(String url, String microservice) {
        ctx.setCurrentUrl(UrlBuilder.toEnvUrl(url));
        ctx.setCurrentMicroservice(microservice);
        log.info("Endpoint: {}", ctx.getCurrentUrl().substring(0, Math.min(120, ctx.getCurrentUrl().length())));
    }

    @Given("the API name is {string}")
    public void setApiName(String apiName) {
        ctx.setCurrentApiName(apiName);
    }

    @Given("device ID is {string}")
    public void setDeviceId(String deviceId) {
        ctx.setDeviceId(deviceId);
    }

    @Given("SIM ID is {string}")
    public void setSimId(String simId) {
        ctx.setSimId(simId);
    }

    @Given("MAC ID is {string}")
    public void setMacId(String macId) {
        ctx.setMacId(macId);
    }

    @Given("MEID is {string}")
    public void setMeid(String meid) {
        ctx.setMeid(meid);
    }

    @Given("app type is {string}")
    public void setAppType(String appType) {
        ctx.setAppType(appType);
    }

    @Given("client ID is {string}")
    public void setClientId(String clientId) {
        ctx.setClientId(clientId);
    }

    // ══════════════════════════════════════════════════════════
    //  WHEN
    // ══════════════════════════════════════════════════════════

    @When("the client sends a GET request")
    public void sendGetRequest() {
        String url = ctx.getCurrentUrl();
        log.info("GET → {}", url.substring(0, Math.min(120, url.length())));
        Response response = ApiClient.get().getFromFullUrl(url);
        ctx.setCurrentResponse(response);
        log.info("HTTP {} ← {}", response.getStatusCode(),
            ctx.getCurrentApiName() != null ? ctx.getCurrentApiName() : url);
    }

    @When("the client sends a GET request with parameters")
    public void sendGetRequestWithParams() {
        String rawUrl = ctx.getCurrentUrl();
        Map<String, String> params = UrlBuilder.extractQueryParams(rawUrl);
        params.replaceAll((k, v) -> substituteDynamic(v));
        String path = UrlBuilder.extractPath(rawUrl);
        Response response = ApiClient.get().get(path, params);
        ctx.setCurrentResponse(response);
        log.info("HTTP {} ← {}", response.getStatusCode(), path);
    }

    // ══════════════════════════════════════════════════════════
    //  THEN  — Status
    // ══════════════════════════════════════════════════════════

    @Then("the response status code should be {int}")
    public void assertStatusCode(int expected) {
        validator().assertStatusCode(expected);
    }

    @Then("the response should be successful")
    public void assertResponseSuccessful() {
        validator().assertSuccess().assertBodyNotEmpty();
    }

    // ══════════════════════════════════════════════════════════
    //  THEN  — DMD business code
    // ══════════════════════════════════════════════════════════

    @Then("the DMD status code in response should be {string}")
    public void assertDmdStatusCode(String code) {
        validator().assertDmdStatusCode(code);
    }

    @Then("the response message should be {string}")
    public void assertResponseMessage(String message) {
        validator().assertResponseMessage(message);
    }

    // ══════════════════════════════════════════════════════════
    //  THEN  — Field presence
    // ══════════════════════════════════════════════════════════

    @Then("the response should contain field {string}")
    public void assertFieldPresent(String xpath) {
        validator().assertFieldPresent(xpath);
    }

    @Then("the response should contain fields:")
    public void assertFieldsPresent(List<String> xpaths) {
        validator().assertFieldsPresent(xpaths);
    }

    // ══════════════════════════════════════════════════════════
    //  THEN  — Field value
    // ══════════════════════════════════════════════════════════

    @Then("the field {string} should have value {string}")
    public void assertFieldValue(String xpath, String value) {
        validator().assertFieldValue(xpath, value);
    }

    @Then("the field {string} should contain {string}")
    public void assertFieldContains(String xpath, String value) {
        validator().assertFieldContains(xpath, value);
    }

    // ══════════════════════════════════════════════════════════
    //  THEN  — Body / element
    // ══════════════════════════════════════════════════════════

    @Then("the response body should not be empty")
    public void assertBodyNotEmpty() {
        validator().assertBodyNotEmpty();
    }

    @Then("the response should contain XML element {string}")
    public void assertXmlElementPresent(String elementName) {
        validator().assertXmlElementPresent(elementName);
    }

    // ══════════════════════════════════════════════════════════
    //  Helpers
    // ══════════════════════════════════════════════════════════

    private XmlResponseValidator validator() {
        assertThat(ctx.getCurrentResponse())
            .as("No HTTP response found — did you call 'the client sends a GET request'?")
            .isNotNull();
        return new XmlResponseValidator(ctx.getCurrentResponse());
    }

    private String substituteDynamic(String value) {
        if (ctx.getDeviceId() != null) value = value.replace("${deviceId}", ctx.getDeviceId());
        if (ctx.getSimId()    != null) value = value.replace("${simId}",    ctx.getSimId());
        if (ctx.getMacId()    != null) value = value.replace("${macId}",    ctx.getMacId());
        if (ctx.getMeid()     != null) value = value.replace("${meid}",     ctx.getMeid());
        if (ctx.getAppType()  != null) value = value.replace("${appType}",  ctx.getAppType());
        if (ctx.getClientId() != null) value = value.replace("${clientId}", ctx.getClientId());
        return value;
    }
}
