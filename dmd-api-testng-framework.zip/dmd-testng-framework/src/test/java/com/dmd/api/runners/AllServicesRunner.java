package com.dmd.api.runners;

import io.cucumber.testng.CucumberOptions;

/**
 * Master TestNG Cucumber runner — executes ALL DMD microservice features.
 *
 * Used when running the full regression suite:
 *   mvn test -Denv=stage
 *   mvn test -Denv=prod
 *
 * For tag-filtered runs:
 *   mvn test -Denv=stage -Dcucumber.filter.tags="@smoke"
 *   mvn test -Denv=stage -Dcucumber.filter.tags="@DMDFeatures"
 */
@CucumberOptions(
    features  = "src/test/resources/features",
    glue      = {"com.dmd.api.stepdefs", "com.dmd.api.hooks"},
    plugin    = {
        "pretty",
        "json:target/cucumber-reports/all-services.json",
        "html:target/cucumber-reports/all-services.html",
        "tech.grasshopper.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
    },
    monochrome = true,
    publish    = false
)
public class AllServicesRunner extends AbstractCucumberRunner {
}
