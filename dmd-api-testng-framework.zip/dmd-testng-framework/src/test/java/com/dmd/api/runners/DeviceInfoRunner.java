package com.dmd.api.runners;

import io.cucumber.testng.CucumberOptions;

/**
 * TestNG Cucumber runner for the <b>dmd-device-info</b> microservice.
 *
 * Triggered by:
 *   mvn test -Pdmd-device-info -Denv=stage
 *   mvn test -Pdmd-device-info -Denv=prod
 *
 * Or via TestNG suite:
 *   src/test/resources/testng-suites/dmd-device-info.xml
 */
@CucumberOptions(
    features  = "src/test/resources/features/dmd-device-info",
    glue      = {"com.dmd.api.stepdefs", "com.dmd.api.hooks"},
    plugin    = {
        "pretty",
        "json:target/cucumber-reports/dmd-device-info.json",
        "html:target/cucumber-reports/dmd-device-info.html",
        "tech.grasshopper.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
    },
    monochrome = true,
    publish    = false
)
public class DeviceInfoRunner extends AbstractCucumberRunner {
}
