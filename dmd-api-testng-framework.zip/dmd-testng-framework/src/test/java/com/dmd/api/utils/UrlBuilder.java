package com.dmd.api.utils;

import com.dmd.api.config.EnvironmentConfig;
import lombok.extern.slf4j.Slf4j;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Converts Excel prod URLs to the target environment base URL at runtime.
 * All feature file URLs reference the prod host — this class swaps the host portion
 * with whatever is configured in config/{env}.properties.
 */
@Slf4j
public class UrlBuilder {

    private static final String PROD_BASE = "https://dmdprod-awswest.verizon.com/dmd";

    private UrlBuilder() {}

    /** Replace prod base with the environment-specific base URL. */
    public static String toEnvUrl(String excelUrl) {
        String envBase = EnvironmentConfig.get().getBaseUrl();
        String result  = excelUrl.replace(PROD_BASE, envBase);
        log.debug("URL → {}", result.substring(0, Math.min(100, result.length())));
        return result;
    }

    /** Extract just the path segment (no query string). */
    public static String extractPath(String fullUrl) {
        String stripped = fullUrl
            .replace(PROD_BASE, "")
            .replace(EnvironmentConfig.get().getBaseUrl(), "");
        int q = stripped.indexOf('?');
        return q >= 0 ? stripped.substring(0, q) : stripped;
    }

    /** Parse query parameters from the full URL into an ordered map. */
    public static Map<String, String> extractQueryParams(String fullUrl) {
        Map<String, String> params = new LinkedHashMap<>();
        int q = fullUrl.indexOf('?');
        if (q < 0) return params;
        String qs = fullUrl.substring(q + 1);

        // Split on & but not inside XML tags
        for (String token : qs.split("&(?![^<>]*>)")) {
            int eq = token.indexOf('=');
            if (eq <= 0) continue;
            String key = token.substring(0, eq);
            String val = token.substring(eq + 1);
            try { val = URLDecoder.decode(val, StandardCharsets.UTF_8); }
            catch (Exception ignored) {}
            params.put(key, val);
        }
        return params;
    }
}
