package com.dmd.api.listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.dmd.api.config.EnvironmentConfig;
import lombok.extern.slf4j.Slf4j;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;

/**
 * TestNG ITestListener that creates a standalone Extent report in addition to
 * the Cucumber adapter report.
 *
 * This listener captures TestNG-level events (pass / fail / skip) and writes
 * them to:  target/extent-reports/TestNGReport/index.html
 *
 * The Cucumber adapter (ExtentCucumberAdapter) writes its own richer report to:
 *           target/extent-reports/SparkReport/index.html
 *
 * Both are uploaded as CI artifacts and attached to the email.
 */
@Slf4j
public class ExtentTestNGReportListener implements ITestListener {

    private static ExtentReports extent;
    private static final ThreadLocal<ExtentTest> testLocal = new ThreadLocal<>();

    @Override
    public void onStart(ITestContext context) {
        EnvironmentConfig cfg = EnvironmentConfig.get();
        String reportPath = cfg.getReportDir() + "/TestNGReport/index.html";

        new File(cfg.getReportDir() + "/TestNGReport").mkdirs();

        ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);
        spark.config().setDocumentTitle("DMD API TestNG Report");
        spark.config().setReportName("DMD API — " + cfg.getEnv().toUpperCase()
            + " | " + cfg.getMicroservice());
        spark.config().setTheme(Theme.DARK);
        spark.config().setEncoding("UTF-8");

        extent = new ExtentReports();
        extent.attachReporter(spark);
        extent.setSystemInfo("Environment",  cfg.getEnv().toUpperCase());
        extent.setSystemInfo("Microservice", cfg.getMicroservice());
        extent.setSystemInfo("BaseURL",      cfg.getBaseUrl());
        extent.setSystemInfo("Build",        System.getProperty("build.number", "local"));

        log.info("ExtentReports initialised → {}", reportPath);
    }

    @Override
    public void onTestStart(ITestResult result) {
        ExtentTest test = extent.createTest(
            result.getTestClass().getName() + " :: " + result.getName()
        );
        testLocal.set(test);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        testLocal.get().pass("Scenario passed");
        log.debug("PASS: {}", result.getName());
    }

    @Override
    public void onTestFailure(ITestResult result) {
        Throwable t = result.getThrowable();
        testLocal.get().fail(t != null ? t : new RuntimeException("Test failed with no exception"));
        log.debug("FAIL: {}", result.getName());
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        testLocal.get().skip("Scenario skipped");
        log.debug("SKIP: {}", result.getName());
    }

    @Override
    public void onFinish(ITestContext context) {
        if (extent != null) {
            extent.flush();
            log.info("TestNG Extent report flushed → {}/TestNGReport/index.html",
                EnvironmentConfig.get().getReportDir());
        }
        testLocal.remove();
    }
}
