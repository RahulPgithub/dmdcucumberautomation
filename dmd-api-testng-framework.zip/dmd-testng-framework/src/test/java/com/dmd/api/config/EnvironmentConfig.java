package com.dmd.api.config;

import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Singleton that loads the correct environment config at startup.
 * Driven by JVM system property: -Denv=stage|prod  (default: stage)
 */
@Slf4j
public class EnvironmentConfig {

    private static final EnvironmentConfig INSTANCE = new EnvironmentConfig();
    private final Properties props = new Properties();
    private final String env;

    private EnvironmentConfig() {
        env = System.getProperty("env", "stage").toLowerCase().trim();
        String configFile = "config/" + env + ".properties";
        log.info("Loading environment config: {}", configFile);
        try (InputStream is = getClass().getClassLoader().getResourceAsStream(configFile)) {
            if (is == null) {
                throw new RuntimeException("Config file not found on classpath: " + configFile);
            }
            props.load(is);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load config: " + configFile, e);
        }
        log.info("Env={} | BaseURL={}", env, getBaseUrl());
    }

    public static EnvironmentConfig get() {
        return INSTANCE;
    }

    public String getBaseUrl()            { return props.getProperty("base.url"); }
    public String getEnv()                { return env; }
    public int    getConnectionTimeout()  { return intProp("connection.timeout", 30000); }
    public int    getReadTimeout()        { return intProp("read.timeout", 60000); }
    public String getEmailSmtpHost()      { return props.getProperty("email.smtp.host", ""); }
    public int    getEmailSmtpPort()      { return intProp("email.smtp.port", 587); }
    public String getEmailFrom()          { return props.getProperty("email.from", ""); }
    public String[] getEmailTo()          { return props.getProperty("email.to", "").split(","); }
    public String getEmailSubjectPrefix() { return props.getProperty("email.subject.prefix", "[DMD]"); }
    public String getReportDir()          { return props.getProperty("report.dir", "target/extent-reports"); }
    public String getMicroservice()       { return System.getProperty("microservice", "all"); }

    private int intProp(String key, int def) {
        try { return Integer.parseInt(props.getProperty(key, String.valueOf(def))); }
        catch (NumberFormatException e) { return def; }
    }
}
