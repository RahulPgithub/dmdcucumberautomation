package com.dmd.api.runners;

import io.cucumber.testng.CucumberOptions;

/**
 * TestNG Cucumber runner for the <b>dmd-multidevice-lookup</b> microservice.
 */
@CucumberOptions(
    features  = "src/test/resources/features/dmd-multidevice-lookup",
    glue      = {"com.dmd.api.stepdefs", "com.dmd.api.hooks"},
    plugin    = {
        "pretty",
        "json:target/cucumber-reports/dmd-multidevice-lookup.json",
        "html:target/cucumber-reports/dmd-multidevice-lookup.html",
        "tech.grasshopper.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
    },
    monochrome = true,
    publish    = false
)
public class MultiDeviceLookupRunner extends AbstractCucumberRunner {
}
