package com.dmd.api.runners;

import io.cucumber.testng.CucumberOptions;

/**
 * TestNG Cucumber runner for the <b>dmd-data-service</b> microservice.
 *
 * Triggered by:
 *   mvn test -Pdmd-data-service -Denv=stage
 */
@CucumberOptions(
    features  = "src/test/resources/features/dmd-data-service",
    glue      = {"com.dmd.api.stepdefs", "com.dmd.api.hooks"},
    plugin    = {
        "pretty",
        "json:target/cucumber-reports/dmd-data-service.json",
        "html:target/cucumber-reports/dmd-data-service.html",
        "tech.grasshopper.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
    },
    monochrome = true,
    publish    = false
)
public class DataServiceRunner extends AbstractCucumberRunner {
}
