package com.dmd.api.utils;

import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

/**
 * Fluent validator for XML API responses.
 *
 * Validations supported:
 *  - HTTP status code
 *  - DMD business status code  (//statusCode = "00")
 *  - Field presence via XPath
 *  - Field value equality / contains
 *  - Raw body not-empty check
 *  - XML element existence check
 */
@Slf4j
public class XmlResponseValidator {

    private final Response response;
    private Document document;

    public XmlResponseValidator(Response response) {
        this.response = response;
        parseDocument();
    }

    // ── Parse ───────────────────────────────────────────────────────────────

    private void parseDocument() {
        try {
            String body = response.getBody().asString();
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(false);
            dbf.setValidating(false);
            dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            document = dbf.newDocumentBuilder()
                .parse(new InputSource(new StringReader(body)));
        } catch (Exception e) {
            log.warn("Response body is not valid XML: {}", e.getMessage());
            document = null;
        }
    }

    // ── HTTP assertions ──────────────────────────────────────────────────────

    public XmlResponseValidator assertStatusCode(int expected) {
        assertThat(response.getStatusCode())
            .as("HTTP Status Code")
            .isEqualTo(expected);
        return this;
    }

    public XmlResponseValidator assertSuccess() {
        return assertStatusCode(200);
    }

    // ── DMD business code ────────────────────────────────────────────────────

    public XmlResponseValidator assertDmdStatusCode(String expectedCode) {
        String actual = xpathValue("//statusCode");
        assertThat(actual)
            .as("DMD <statusCode> in XML response")
            .isEqualTo(expectedCode);
        return this;
    }

    // ── Field presence ────────────────────────────────────────────────────────

    public XmlResponseValidator assertFieldPresent(String xpath) {
        String val = xpathValue(xpath);
        assertThat(val)
            .as("Field present at XPath [%s]", xpath)
            .isNotNull()
            .isNotBlank();
        return this;
    }

    public XmlResponseValidator assertFieldsPresent(List<String> xpaths) {
        xpaths.forEach(this::assertFieldPresent);
        return this;
    }

    // ── Field value ───────────────────────────────────────────────────────────

    public XmlResponseValidator assertFieldValue(String xpath, String expected) {
        String actual = xpathValue(xpath);
        assertThat(actual)
            .as("Value at XPath [%s]", xpath)
            .isEqualTo(expected);
        return this;
    }

    public XmlResponseValidator assertFieldContains(String xpath, String substring) {
        String actual = xpathValue(xpath);
        assertThat(actual)
            .as("Value at XPath [%s] should contain [%s]", xpath, substring)
            .contains(substring);
        return this;
    }

    // ── Body checks ───────────────────────────────────────────────────────────

    public XmlResponseValidator assertBodyNotEmpty() {
        assertThat(response.getBody().asString())
            .as("Response body must not be empty")
            .isNotNull()
            .isNotBlank();
        return this;
    }

    public XmlResponseValidator assertXmlElementPresent(String elementName) {
        assertThat(response.getBody().asString())
            .as("Response body should contain XML element <%s>", elementName)
            .contains("<" + elementName);
        return this;
    }

    public XmlResponseValidator assertResponseMessage(String message) {
        return assertFieldValue("//message", message);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public String xpathValue(String xpath) {
        if (document == null) {
            fail("Cannot evaluate XPath — response was not valid XML.\nBody: "
                + response.getBody().asString());
        }
        try {
            XPath xp = XPathFactory.newInstance().newXPath();
            return (String) xp.evaluate(xpath, document, XPathConstants.STRING);
        } catch (Exception e) {
            log.error("XPath evaluation error [{}]: {}", xpath, e.getMessage());
            return null;
        }
    }

    public int    getHttpStatusCode()  { return response.getStatusCode(); }
    public String getRawBody()         { return response.getBody().asString(); }
    public Response getResponse()      { return response; }
}
