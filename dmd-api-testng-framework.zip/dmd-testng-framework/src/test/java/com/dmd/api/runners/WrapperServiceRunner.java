package com.dmd.api.runners;

import io.cucumber.testng.CucumberOptions;

/**
 * TestNG Cucumber runner for the <b>dmd-wrapper-service</b> microservice.
 */
@CucumberOptions(
    features  = "src/test/resources/features/dmd-wrapper-service",
    glue      = {"com.dmd.api.stepdefs", "com.dmd.api.hooks"},
    plugin    = {
        "pretty",
        "json:target/cucumber-reports/dmd-wrapper-service.json",
        "html:target/cucumber-reports/dmd-wrapper-service.html",
        "tech.grasshopper.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
    },
    monochrome = true,
    publish    = false
)
public class WrapperServiceRunner extends AbstractCucumberRunner {
}
