package com.dmd.api.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import lombok.extern.slf4j.Slf4j;
import org.testng.annotations.DataProvider;

/**
 * Base class for all DMD microservice runners.
 *
 * Extending {@link AbstractTestNGCucumberTests} is the TestNG equivalent of
 * the JUnit 5 {@code @Suite} approach.  Each subclass overrides
 * {@code @CucumberOptions} to point at its own features directory.
 *
 * Key TestNG integration points:
 *  - {@code @DataProvider(parallel = true)}  → parallel scenario execution
 *  - TestNG {@code @BeforeSuite / @AfterSuite} in the Listener handles email
 *  - TestNG XML suite files control which runner is active per CI job
 */
@Slf4j
public abstract class AbstractCucumberRunner extends AbstractTestNGCucumberTests {

    /**
     * Enable parallel scenario execution per runner.
     * Set parallel=false to run scenarios sequentially within a service.
     */
    @Override
    @DataProvider(parallel = false)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
