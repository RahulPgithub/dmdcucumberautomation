# DMD API Test Framework — Cucumber 7 + TestNG + Maven

Production-ready API automation framework for all DMD microservices.
Uses **Cucumber 7** for BDD feature files and **TestNG** as the test runner
(replacing JUnit 5).

---

## Key Difference from JUnit Version

| Aspect | JUnit 5 version | This TestNG version |
|---|---|---|
| Runner base class | `@Suite` + `@SelectDirectories` | `extends AbstractTestNGCucumberTests` |
| Suite control | JUnit Platform Suite | TestNG XML files (`testng-suites/*.xml`) |
| Parallel execution | JUnit Platform parallel | TestNG `parallel="tests"` in XML |
| Suite lifecycle | `@AfterAll` (static) | `ISuiteListener.onFinish()` |
| Test lifecycle | `@BeforeEach` / `@AfterEach` | `ITestListener.onTestStart/Finish()` |
| CI runner trigger | `-Dtest=RunnerClass` | `-DsuiteFile=path/to/suite.xml` |

Everything else — feature files, step definitions, REST Assured client,
XPath validators, email reporter — is identical.

---

## Project Structure

```
dmd-api-testng-framework/
├── pom.xml
├── README.md
├── .gitignore
├── .github/workflows/
│   ├── ci.yml                  ← detects changed service, fires the right job
│   └── run-tests.yml           ← reusable job (TestNG suite_file input)
└── src/test/
    ├── java/com/dmd/api/
    │   ├── config/
    │   │   └── EnvironmentConfig.java
    │   ├── model/
    │   │   └── ScenarioContext.java
    │   ├── utils/
    │   │   ├── ApiClient.java
    │   │   ├── XmlResponseValidator.java
    │   │   ├── UrlBuilder.java
    │   │   └── EmailReporter.java
    │   ├── stepdefs/
    │   │   └── ApiStepDefs.java
    │   ├── hooks/
    │   │   └── CucumberHooks.java       ← @Before/@After (Cucumber)
    │   ├── listeners/
    │   │   ├── TestNGSuiteListener.java ← ISuiteListener (email on finish)
    │   │   └── ExtentTestNGReportListener.java ← ITestListener (Extent)
    │   └── runners/
    │       ├── AbstractCucumberRunner.java  ← extends AbstractTestNGCucumberTests
    │       ├── AllServicesRunner.java
    │       ├── DeviceInfoRunner.java
    │       ├── DataServiceRunner.java
    │       ├── FeaturesServiceRunner.java
    │       ├── MultiDeviceLookupRunner.java
    │       └── WrapperServiceRunner.java
    └── resources/
        ├── config/
        │   ├── stage.properties
        │   └── prod.properties
        ├── testng-suites/
        │   ├── all-services.xml
        │   ├── dmd-device-info.xml
        │   ├── dmd-data-service.xml
        │   ├── dmd-features-service.xml
        │   ├── dmd-multidevice-lookup.xml
        │   └── dmd-wrapper-service.xml
        ├── features/
        │   ├── dmd-device-info/        (18 APIs, 22 scenarios)
        │   ├── dmd-data-service/       (6 APIs,  9 scenarios)
        │   ├── dmd-features-service/   (1 API,   9 scenarios)
        │   ├── dmd-multidevice-lookup/ (1 API,   3 scenarios)
        │   └── dmd-wrapper-service/    (2 APIs,  4 scenarios)
        ├── extent.properties
        └── logback-test.xml
```

---

## Running Tests

### Full suite — Stage
```bash
mvn test -Denv=stage
```

### Full suite — Prod
```bash
mvn test -Denv=prod
```

### Single microservice via Maven profile
```bash
mvn test -Pdmd-device-info        -Denv=stage
mvn test -Pdmd-data-service       -Denv=stage
mvn test -Pdmd-features-service   -Denv=stage
mvn test -Pdmd-multidevice-lookup -Denv=stage
mvn test -Pdmd-wrapper-service    -Denv=stage
```

### Single microservice — explicit suite file
```bash
mvn test -Denv=stage \
         -DsuiteFile=src/test/resources/testng-suites/dmd-device-info.xml
```

### Smoke tests only
```bash
mvn test -Denv=stage -Dcucumber.filter.tags="@smoke"
```

### Specific API tag
```bash
mvn test -Denv=stage -Dcucumber.filter.tags="@DMDFeatures"
mvn test -Denv=stage -Dcucumber.filter.tags="@DMDMultiDeviceLookupAPI"
```

### Combine tag + service
```bash
mvn test -Pdmd-device-info -Denv=prod -Dcucumber.filter.tags="@smoke"
```

---

## Test Reports

After every run two reports are generated:

| Report | Path | Description |
|---|---|---|
| Extent Spark (Cucumber) | `target/extent-reports/SparkReport/index.html` | Rich BDD report from Cucumber adapter |
| Extent TestNG | `target/extent-reports/TestNGReport/index.html` | TestNG-level report from ITestListener |
| Cucumber HTML | `target/cucumber-reports/<service>.html` | Built-in Cucumber HTML |
| Cucumber JSON | `target/cucumber-reports/<service>.json` | For CI integration |
| TestNG Surefire | `target/surefire-reports/` | Standard TestNG XML results |

Open the Spark report in any browser. It includes per-scenario pass/fail,
request/response body on failure, and system info (environment, microservice, build).

---

## Email Report

Sent automatically after each suite run by `TestNGSuiteListener.onFinish()`.

Configure SMTP in `src/test/resources/config/{env}.properties`:
```properties
email.smtp.host=smtp.yourcompany.com
email.smtp.port=587
email.from=dmd-automation@yourcompany.com
email.to=team@yourcompany.com,qa@yourcompany.com
```

Set credentials as environment variables:
```bash
export EMAIL_USER=smtp-username
export EMAIL_PASS=smtp-password
```

The email includes:
- Pass / Fail / Skipped counts + pass rate
- Environment and microservice context
- Extent HTML report as attachment

---

## CI/CD — GitHub Actions

Every push triggers `ci.yml` which:

1. **Detects changed paths** using `dorny/paths-filter`
2. **Fires only the relevant service job(s)**
3. Each job calls `run-tests.yml` (reusable workflow) with:
   - `suite_file` → the TestNG XML for that service
   - `environment` → stage (default) or prod
   - `tag_filter` → optional Cucumber tag
4. Uploads **Extent HTML** + **TestNG XML** + **Cucumber JSON** as artifacts
5. Publishes a **test summary** on the PR / commit via `dorny/test-reporter`
6. Sends **email** after the run

### Manual trigger

**Actions → DMD API Tests (TestNG) → Run workflow**

Select: environment | microservice | optional tag filter

### Required GitHub Secrets

| Secret | Purpose |
|---|---|
| `EMAIL_USER` | SMTP username |
| `EMAIL_PASS` | SMTP password |

---

## How TestNG Suite XML Controls Execution

The TestNG XML files are the control plane. The `pom.xml` Surefire config
points to `${suiteFile}` which defaults to `all-services.xml` but is
overridden per Maven profile:

```xml
<!-- pom.xml surefire config -->
<suiteXmlFiles>
    <suiteXmlFile>${suiteFile}</suiteXmlFile>
</suiteXmlFiles>
```

The all-services suite runs all 5 runners **in parallel** (one thread per service):
```xml
<suite name="DMD API Full Suite" parallel="tests" thread-count="5">
```

The per-service suites run that service's runner only.

---

## Adding a New API

1. Add a `Scenario` to the appropriate `.feature` file
2. Tag it `@smoke` or `@regression` + `@ApiName`
3. No Java changes needed — all steps are generic
4. Push → CI detects the changed feature file → runs only that service's suite

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `Could not parse response as XML` | API returned non-XML. Check logs for actual body. |
| `No HTTP response — did you call 'the client sends a GET request'?` | Step order issue in feature file |
| All tests skipped | Check `@CucumberOptions` tag filter vs scenario tags |
| Email not sent | Set `EMAIL_USER`/`EMAIL_PASS` env vars + verify SMTP host |
| TestNG XML suite not found | Run `mvn test -DsuiteFile=src/test/...` with full path |
