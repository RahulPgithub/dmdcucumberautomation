# DMD API Test Framework — Cucumber 7 + TestNG

Complete API automation for all DMD microservices.
Supports **XML** and **JSON REST** API validation across **Stage, QA and Production**.

## Quick Start

```bash
# Full suite — Stage
mvn test -Denv=stage

# Full suite — QA
mvn test -Denv=qa

# Full suite — Prod
mvn test -Denv=prod

# Single microservice
mvn test -Pstage,dmd-device-info
mvn test -Pqa,dmd-data-service
mvn test -Pprod,dmd-features-service

# XML only
mvn test -Denv=stage -Dcucumber.filter.tags="@xml"

# JSON only
mvn test -Denv=stage -Dcucumber.filter.tags="@json"

# Smoke only
mvn test -Denv=stage -Dcucumber.filter.tags="@smoke"

# Specific API
mvn test -Denv=stage -Dcucumber.filter.tags="@DMDFeatures"
```

## Environment URLs

Configure per-service URLs in `src/test/resources/config/{env}.properties`:

| Property | Purpose |
|---|---|
| `base.url` | Default XML API base URL |
| `service.{name}.base.url` | Per-service XML URL override |
| `json.{name}.base.url` | Per-service JSON REST API URL |
| `json.auth.enabled` | Enable Bearer token auth for JSON APIs |
| `json.auth.token` | Static Bearer token |

## Project Structure

```
src/test/
├── java/com/dmd/api/
│   ├── config/EnvironmentConfig.java       ← stage/qa/prod URL resolution
│   ├── model/ScenarioContext.java          ← DI shared state (XML + JSON)
│   ├── utils/
│   │   ├── ApiClient.java                  ← HTTP client (XML + JSON methods)
│   │   ├── XmlResponseValidator.java       ← XPath XML assertions
│   │   ├── JsonResponseValidator.java      ← JsonPath JSON assertions
│   │   ├── UrlBuilder.java                 ← Env URL substitution
│   │   └── EmailReporter.java              ← HTML email after suite
│   ├── stepdefs/
│   │   ├── ApiStepDefs.java                ← XML step definitions
│   │   └── JsonApiStepDefs.java            ← JSON step definitions
│   ├── hooks/CucumberHooks.java            ← Before/After + counters
│   ├── listeners/
│   │   ├── TestNGSuiteListener.java        ← ISuiteListener (email on finish)
│   │   └── ExtentTestNGReportListener.java ← ITestListener (Extent)
│   └── runners/
│       ├── AbstractCucumberRunner.java     ← Base: extends AbstractTestNGCucumberTests
│       ├── AllServicesRunner.java
│       ├── DeviceInfoRunner.java
│       ├── DataServiceRunner.java
│       ├── FeaturesServiceRunner.java
│       ├── MultiDeviceLookupRunner.java
│       └── WrapperServiceRunner.java
└── resources/
    ├── config/
    │   ├── stage.properties
    │   ├── qa.properties
    │   └── prod.properties
    ├── testng-suites/                      ← 6 TestNG XML suite files
    ├── features/
    │   ├── dmd-device-info/                ← XML + JSON feature files
    │   ├── dmd-data-service/
    │   ├── dmd-features-service/
    │   ├── dmd-multidevice-lookup/
    │   └── dmd-wrapper-service/
    ├── extent.properties
    └── logback-test.xml
```

## Reports

| Report | Location |
|---|---|
| Extent Spark (Cucumber) | `target/extent-reports/SparkReport/index.html` |
| Extent TestNG | `target/extent-reports/TestNGReport/index.html` |
| Cucumber HTML | `target/cucumber-reports/{service}.html` |
| Cucumber JSON | `target/cucumber-reports/{service}.json` |
| TestNG Surefire | `target/surefire-reports/` |

## CI/CD

On every push, GitHub Actions detects which microservice changed and runs only that service's suite. Manual trigger allows selecting environment + microservice + tag filter.

Required GitHub Secrets: `EMAIL_USER`, `EMAIL_PASS`
