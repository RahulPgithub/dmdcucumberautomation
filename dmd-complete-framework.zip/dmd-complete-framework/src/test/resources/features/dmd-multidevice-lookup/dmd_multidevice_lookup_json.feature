@dmd-multidevice-lookup @json
Feature: DMD MultiDevice Lookup Service - JSON API

  Background:
    Given the API name is "dmd-multidevice-lookup"

  @smoke @json-multidevice
  Scenario: JSON - multi device lookup single pair
    Given the JSON API path is "/lookup?deviceId=359324081412299&simId=89148000004735113345&clientId=POS&appType=NETACE" for microservice "dmd-multidevice-lookup"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    And   the JSON DMD message should be "SUCCESS"
    And   the JSON response should contain field "deviceId"
    And   the JSON response should contain field "simId"
    And   the JSON field "deviceId" should be "359324081412299"

  @regression @json-multidevice
  Scenario Outline: JSON - multi device lookup data-driven
    Given the JSON API path is "/lookup?deviceId=<deviceId>&simId=<simId>&clientId=POS" for microservice "dmd-multidevice-lookup"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    Examples:
      | deviceId        | simId                |
      | 359324081412299 | 89148000004735113345 |
      | 99000044000074  | 89148000004735113345 |
