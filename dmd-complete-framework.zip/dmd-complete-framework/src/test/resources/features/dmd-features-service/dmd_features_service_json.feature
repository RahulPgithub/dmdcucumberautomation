@dmd-features-service @json
Feature: DMD Features Service - JSON API
  JSON REST API tests for dmd-features-service microservice.

  Background:
    Given the API name is "dmd-features-service"

  @smoke @json-features
  Scenario: JSON - features by deviceId and simId
    Given the JSON API path is "/features?deviceId=359324081412299&simId=89148000004735113345" for microservice "dmd-features-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    And   the JSON DMD message should be "SUCCESS"
    And   the JSON response should contain field "deviceId"
    And   the JSON response should contain field "simId"
    And   the JSON response should contain field "features"
    And   the JSON array "features" should not be empty

  @smoke @json-features
  Scenario: JSON - features by deviceId only
    Given the JSON API path is "/features?deviceId=A0000007077057" for microservice "dmd-features-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    And   the JSON response should contain field "features"

  @smoke @json-features
  Scenario: JSON - features POSBE appType DMDSRVR clientId
    Given the JSON API path is "/features?deviceId=359324081412299&simId=89148000004735113345&appType=POSBE&clientId=DMDSRVR" for microservice "dmd-features-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    And   the JSON response should contain field "features"

  @regression @json-features
  Scenario Outline: JSON - features data-driven
    Given the JSON API path is "/features?deviceId=<deviceId>&simId=<simId>&appType=<appType>" for microservice "dmd-features-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    And   the JSON response should contain field "features"
    Examples:
      | deviceId        | simId                | appType |
      | 359324081412299 | 89148000004735113345 | NETACE  |
      | 99000044000074  | 89148000004735113345 | POS     |
