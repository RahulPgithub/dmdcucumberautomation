@dmd-features-service @xml
Feature: DMD Features Service - XML API
  XML API tests for DMDFeatures (dmd-features-service microservice).

  Background:
    Given the API name is "dmd-features-service"

  @smoke @DMDFeatures
  Scenario: DMDFeatures - empty appType deviceId+simId
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>359324081412299</deviceId><simId>89148000004735113345</simId></requestBody></dmd>" for microservice "dmd-features-service"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    And   the response should contain field "//statusCode"
    And   the response message should be "SUCCESS"

  @smoke @DMDFeatures
  Scenario: DMDFeatures - NetACE appType POS clientId
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType>NetACE</appType><requestId>sadsadssaf</requestId></requestHeader><clientId>POS</clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>359324081412299</deviceId><simId>89148000004735113345</simId></requestBody></dmd>" for microservice "dmd-features-service"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    And   the response message should be "SUCCESS"

  @smoke @DMDFeatures
  Scenario: DMDFeatures - POSBE appType DMDSRVR clientId
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType>POSBE</appType><requestId/></requestHeader><clientId>DMDSRVR</clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>359324081412299</deviceId><simId>89148000004735113345</simId></requestBody></dmd>" for microservice "dmd-features-service"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    And   the response message should be "SUCCESS"

  @smoke @DMDFeatures
  Scenario: DMDFeatures - deviceId only
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>A0000007077057</deviceId></requestBody></dmd>" for microservice "dmd-features-service"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"

  @regression @DMDFeatures
  Scenario Outline: DMDFeatures - data-driven deviceId and simId
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeatures?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId><deviceId></deviceId><simId><simId></simId></requestBody></dmd>" for microservice "dmd-features-service"
    And   device ID is "<deviceId>"
    And   SIM ID is "<simId>"
    When  the client sends a GET request with parameters
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    Examples:
      | deviceId        | simId                |
      | 359324081412299 | 89148000004735113345 |
      | 99000044000074  | 89148000004735113345 |
