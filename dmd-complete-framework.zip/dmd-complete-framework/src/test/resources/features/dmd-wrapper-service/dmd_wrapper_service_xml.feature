@dmd-wrapper-service @xml
Feature: DMD Wrapper Service - XML API

  Background:
    Given the API name is "dmd-wrapper-service"

  @smoke @DMDDaccSaccCompatibility
  Scenario: DaccSaccCompatibility - DACC to SACC
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDDaccSaccCompatibility?dacc=00929" for microservice "dmd-wrapper-service"
    When  the client sends a GET request
    Then  the response should be successful
    And   the response body should not be empty
    And   the response should contain XML element "dmd"

  @regression @DMDDaccSaccCompatibility
  Scenario Outline: DaccSaccCompatibility - data-driven
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDDaccSaccCompatibility?dacc=<dacc>" for microservice "dmd-wrapper-service"
    When  the client sends a GET request
    Then  the response should be successful
    Examples:
      | dacc  |
      | 00929 |
      | 00930 |

  @smoke @DMDSaccDaccCompatibility
  Scenario: SaccDaccCompatibility - SACC to DACC
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDSaccDaccCompatibility?sacc=00607" for microservice "dmd-wrapper-service"
    When  the client sends a GET request
    Then  the response should be successful
    And   the response body should not be empty
    And   the response should contain XML element "dmd"

  @regression @DMDSaccDaccCompatibility
  Scenario Outline: SaccDaccCompatibility - data-driven
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDSaccDaccCompatibility?sacc=<sacc>" for microservice "dmd-wrapper-service"
    When  the client sends a GET request
    Then  the response should be successful
    Examples:
      | sacc  |
      | 00607 |
      | 00608 |
