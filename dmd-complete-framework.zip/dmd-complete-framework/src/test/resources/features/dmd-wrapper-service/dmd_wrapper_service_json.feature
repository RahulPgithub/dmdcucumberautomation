@dmd-wrapper-service @json
Feature: DMD Wrapper Service - JSON API

  Background:
    Given the API name is "dmd-wrapper-service"

  @smoke @json-dacc-sacc
  Scenario: JSON - DACC to SACC compatibility
    Given the JSON API path is "/compatibility/dacc-sacc?dacc=00929" for microservice "dmd-wrapper-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    And   the JSON response should contain field "dacc"
    And   the JSON response should contain field "compatibleSacc"
    And   the JSON field "dacc" should be "00929"
    And   the JSON array "compatibleSacc" should not be empty

  @regression @json-dacc-sacc
  Scenario Outline: JSON - DACC compatibility data-driven
    Given the JSON API path is "/compatibility/dacc-sacc?dacc=<dacc>" for microservice "dmd-wrapper-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    Examples:
      | dacc  |
      | 00929 |
      | 00930 |

  @smoke @json-sacc-dacc
  Scenario: JSON - SACC to DACC compatibility
    Given the JSON API path is "/compatibility/sacc-dacc?sacc=00607" for microservice "dmd-wrapper-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    And   the JSON response should contain field "sacc"
    And   the JSON response should contain field "compatibleDacc"
    And   the JSON field "sacc" should be "00607"
    And   the JSON array "compatibleDacc" should not be empty

  @regression @json-sacc-dacc
  Scenario Outline: JSON - SACC compatibility data-driven
    Given the JSON API path is "/compatibility/sacc-dacc?sacc=<sacc>" for microservice "dmd-wrapper-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    Examples:
      | sacc  |
      | 00607 |
      | 00608 |
