@dmd-device-info @xml
Feature: DMD Device Info Service - XML API
  XML API tests for dmd-device-info microservice.
  Base URL auto-switches per -Denv=stage|qa|prod

  Background:
    Given the API name is "dmd-device-info"

  @smoke @DMDLostStolenNonPayInfo
  Scenario: LostStolenNonPayInfo - DVS pairLookup by simId
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDLostStolenNonPayInfo?xmlreqdoc=<dmd><requestHeader><appType>DVS</appType><requestId></requestId></requestHeader><clientId>DVS</clientId><serviceName>retrieveLostStolenNonPayInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><simId>89148000002543383696</simId></requestBody></dmd>" for microservice "dmd-device-info"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    And   the response should contain field "//statusCode"
    And   the response should contain field "//message"
    And   the response message should be "SUCCESS"

  @smoke @DMDLostStolenNonPayInfo
  Scenario: LostStolenNonPayInfo - NETACE pairLookup by deviceId
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDLostStolenNonPayInfo?xmlreqdoc=<dmd><requestHeader><appType>NETACE</appType><requestId></requestId></requestHeader><clientId>NETACE</clientId><serviceName>lostStolenNonPayInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>990004544871985</deviceId></requestBody></dmd>" for microservice "dmd-device-info"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    And   the response message should be "SUCCESS"

  @smoke @DMDBulkDeviceSimLookup
  Scenario: BulkDeviceSimLookup - POS client
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDBulkDeviceSimLookup?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId>POS</clientId><serviceName>DMDBulkDeviceSimLookup</serviceName><subserviceName/><requestBody><devicePair><seqNum>1</seqNum><deviceId>359324081412299</deviceId><simId>89148000004735113345</simId></devicePair></requestBody></dmd>" for microservice "dmd-device-info"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    And   the response should contain field "//devicePair"
    And   the response message should be "SUCCESS"

  @smoke @DMDEquipmentIDXml
  Scenario: EquipmentIDXml - lookup by deviceID
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDEquipmentIDXml?deviceID=A0000003023FD3" for microservice "dmd-device-info"
    When  the client sends a GET request
    Then  the response should be successful
    And   the response body should not be empty
    And   the response should contain XML element "dmd"

  @smoke @DMDFeaturesLight4G
  Scenario: FeaturesLight4G - POS client
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDFeaturesLight4G?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId>POS</clientId><serviceName>retrieveDeviceSimInfo</serviceName><subServiceName>pairLookup</subServiceName><requestBody><deviceId>359324081412299</deviceId></requestBody></dmd>" for microservice "dmd-device-info"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    And   the response message should be "SUCCESS"

  @smoke @DMDMACIDLookup
  Scenario: MACIDLookup - by MACID param
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDMACIDLookup?MACID=00163290D78A" for microservice "dmd-device-info"
    When  the client sends a GET request
    Then  the response should be successful
    And   the response body should not be empty
    And   the response should contain XML element "dmd"

  @smoke @DMDMultiDevice
  Scenario: MultiDevice - deviceSim pair
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDMultiDevice?xmlReq=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><requestBody><deviceSim><deviceId>99000044000074</deviceId><simId>89148000004735113345</simId></deviceSim></requestBody></dmd>" for microservice "dmd-device-info"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"

  @smoke @DMDMultiDeviceSimValidation
  Scenario: MultiDeviceSimValidation - DVS app type
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDMultiDeviceSimValidation?xmlreqdoc=<dmd><requestHeader><appType>DVS</appType><requestId>Rahul_24.11</requestId></requestHeader><requestBody><featureAndDaccAnalysis>false</featureAndDaccAnalysis><deviceSim><deviceId>359324081412299</deviceId><simId>89148000004735113345</simId></deviceSim></requestBody></dmd>" for microservice "dmd-device-info"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    And   the response message should be "SUCCESS"

  @smoke @DMDMultiMakeModel
  Scenario Outline: MultiMakeModel - multiple deviceIDs
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDMultiMakeModel?deviceID=<deviceIDs>" for microservice "dmd-device-info"
    When  the client sends a GET request
    Then  the response should be successful
    And   the response should contain XML element "dmd"
    Examples:
      | deviceIDs                                    |
      | A0000007077057,A0000007077058,A0000007077059 |
      | A0000003023F9A,99000044000076,14112648436    |

  @smoke @DMDScmplus
  Scenario: Scmplus - by meid
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDScmplus?meid=99000044000090" for microservice "dmd-device-info"
    When  the client sends a GET request
    Then  the response should be successful
    And   the response body should not be empty

  @smoke @DMDXml
  Scenario: DMDXml - featuresLight CCES
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDXml?app_type=CCES&action=featuresLight&deviceID=A0000003023FBC" for microservice "dmd-device-info"
    When  the client sends a GET request
    Then  the response should be successful
    And   the response should contain XML element "dmd"

  @smoke @DMDDeviceWarrantyVendorService
  Scenario: DeviceWarrantyVendorService - NETACE
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDDeviceWarrantyVendorService?xmlReq=<dmd><requestHeader><appType>NETACE</appType><requestId>ESQA4pos:vipm2msvc01:01:1600068738990</requestId></requestHeader><clientId>NETACE</clientId><serviceName>getWarrantyVendor</serviceName><requestBody><deviceId>359324081412299</deviceId></requestBody></dmd>" for microservice "dmd-device-info"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    And   the response message should be "SUCCESS"
