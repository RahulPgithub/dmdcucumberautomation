@dmd-data-service @xml
Feature: DMD Data Service - XML API
  XML API tests for dmd-data-service microservice.

  Background:
    Given the API name is "dmd-data-service"

  @smoke @DMDB2BMacidLookup
  Scenario: B2BMacidLookup - DVS DEVICE_SCAN
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDB2BMacidLookup?xmlReq=<dmd><requestHeader><requestId/><clientId>DVS</clientId><requestType>DEVICE_SCAN</requestType><requestApplication>Retail</requestApplication><userId/></requestHeader><requestBody><serviceName>DMDB2BMacidLookup</serviceName><b2bmacId>003044342CFC</b2bmacId></requestBody></dmd>" for microservice "dmd-data-service"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    And   the response should contain field "//statusCode"
    And   the response message should be "SUCCESS"

  @smoke @DMDModelSummary
  Scenario: ModelSummary - WFM app type
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDModelSummary?app_type=WFM&deviceId=6912615731" for microservice "dmd-data-service"
    When  the client sends a GET request
    Then  the response should be successful
    And   the response body should not be empty
    And   the response should contain XML element "dmd"

  @smoke @DMDNegativeCheck
  Scenario: NegativeCheck - DVS device
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDNegativeCheck?xmlReq=<dmd><requestHeader><appType>DVS</appType><requestId></requestId></requestHeader><requestBody><deviceId>A00000231FD3EC</deviceId><deviceType>MEID</deviceType></requestBody></dmd>" for microservice "dmd-data-service"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    And   the response message should be "SUCCESS"

  @smoke @DMDReadDeviceDetails
  Scenario: ReadDeviceDetails - DVS DEVICE_SCAN
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDReadDeviceDetails?xmlreqdoc=<dmd><requestHeader><requestId/><clientId>DVS</clientId><requestType>DEVICE_SCAN</requestType><requestApplication>Retail</requestApplication><userId/></requestHeader><requestBody><serviceName>DMDReadDeviceDetails</serviceName><deviceId>359324081412299</deviceId></requestBody></dmd>" for microservice "dmd-data-service"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    And   the response message should be "SUCCESS"

  @smoke @DMDSIMCompatibility
  Scenario: SIMCompatibility - check SIM compat
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDSIMCompatibility?deviceId=35611609009749" for microservice "dmd-data-service"
    When  the client sends a GET request
    Then  the response should be successful
    And   the response body should not be empty

  @smoke @DMDDeviceCompare
  Scenario: DeviceCompare - by deviceId
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDDeviceCompare?xmlreqdoc=<dmd><requestHeader><appType></appType><requestId></requestId></requestHeader><clientId></clientId><serviceName>DMDDeviceCompare</serviceName><requestBody><deviceId>35241109213316</deviceId></requestBody></dmd>" for microservice "dmd-data-service"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
    And   the response message should be "SUCCESS"

  @regression @DMDDeviceCompare
  Scenario: DeviceCompare - with deviceSku
    Given the API endpoint is "https://dmdprod-awswest.verizon.com/dmd/DMDDeviceCompare?xmlreqdoc=<dmd><requestBody><deviceId>35241109213316</deviceId><deviceSku>SMG965UZKV</deviceSku></requestBody></dmd>" for microservice "dmd-data-service"
    When  the client sends a GET request
    Then  the response should be successful
    And   the DMD status code in response should be "00"
