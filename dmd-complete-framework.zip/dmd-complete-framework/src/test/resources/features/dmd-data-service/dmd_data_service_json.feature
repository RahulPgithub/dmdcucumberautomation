@dmd-data-service @json
Feature: DMD Data Service - JSON API
  JSON REST API tests for dmd-data-service microservice.
  Base URL: json.dmd-data-service.base.url in config/{env}.properties

  Background:
    Given the API name is "dmd-data-service"

  @smoke @json-model-summary
  Scenario: JSON - model summary by deviceId
    Given the JSON API path is "/model-summary?deviceId=6912615731&appType=WFM" for microservice "dmd-data-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    And   the JSON response should contain field "make"
    And   the JSON response should contain field "model"
    And   the JSON response should contain field "deviceId"

  @regression @json-model-summary
  Scenario Outline: JSON - model summary across app types
    Given the JSON API path is "/model-summary?deviceId=<deviceId>&appType=<appType>" for microservice "dmd-data-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    Examples:
      | deviceId   | appType |
      | 6912615731 | WFM     |
      | 6912615731 | DVS     |
      | 6912615731 | NETACE  |

  @smoke @json-sim-compat
  Scenario: JSON - SIM compatibility check
    Given the JSON API path is "/sim-compatibility?deviceId=35611609009749" for microservice "dmd-data-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    And   the JSON response should contain field "compatible"
    And   the JSON response should contain field "deviceId"

  @smoke @json-negative-check
  Scenario: JSON - device negative check
    Given the JSON API path is "/negative-check?deviceId=A00000231FD3EC&deviceType=MEID" for microservice "dmd-data-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    And   the JSON response should contain field "negativeStatus"

  @smoke @json-device-compare
  Scenario: JSON - device compare by deviceId
    Given the JSON API path is "/device-compare?deviceId=35241109213316" for microservice "dmd-data-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    And   the JSON response should contain field "deviceId"
    And   the JSON response should contain field "compareResult"

  @regression @json-device-compare
  Scenario: JSON - device compare with SKU
    Given the JSON API path is "/device-compare?deviceId=35241109213316&deviceSku=SMG965UZKV" for microservice "dmd-data-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON field "deviceId" should be "35241109213316"

  @smoke @json-read-device
  Scenario: JSON - read device details
    Given the JSON API path is "/device-details?deviceId=359324081412299&clientId=DVS" for microservice "dmd-data-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    And   the JSON response should contain field "deviceId"
    And   the JSON response should contain field "deviceDetails"

  @smoke @json-b2b-macid
  Scenario: JSON - B2B MACID lookup
    Given the JSON API path is "/b2b-macid?macId=003044342CFC&clientId=DVS" for microservice "dmd-data-service"
    When  the client sends a JSON GET request
    Then  the JSON response should be successful
    And   the JSON DMD status code should be "00"
    And   the JSON response should contain field "macId"
