package com.dmd.api.listeners;

import com.dmd.api.config.EnvironmentConfig;
import com.dmd.api.hooks.CucumberHooks;
import com.dmd.api.utils.EmailReporter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ISuite;
import org.testng.ISuiteListener;

/**
 * TestNG ISuiteListener — fires once before and after the entire suite.
 * Replaces JUnit 5's @AfterAll.
 *
 * Registered in every testng-suites/*.xml:
 *   <listener class-name="com.dmd.api.listeners.TestNGSuiteListener"/>
 */
public class TestNGSuiteListener implements ISuiteListener {

    private static final Logger log = LoggerFactory.getLogger(TestNGSuiteListener.class);

    @Override
    public void onStart(ISuite suite) {
        EnvironmentConfig cfg = EnvironmentConfig.get();
        log.info("╔══════════════════════════════════════════════════════╗");
        log.info("  DMD API Suite Starting");
        log.info("  Suite       : {}", suite.getName());
        log.info("  Environment : {}", cfg.getEnv().toUpperCase());
        log.info("  Microservice: {}", cfg.getMicroservice());
        log.info("  XML Base URL: {}", cfg.getBaseUrl());
        log.info("╚══════════════════════════════════════════════════════╝");
    }

    @Override
    public void onFinish(ISuite suite) {
        int p     = CucumberHooks.passed.get();
        int f     = CucumberHooks.failed.get();
        int s     = CucumberHooks.skipped.get();
        int total = p + f + s;

        log.info("╔══════════════════════════════════════════════════════╗");
        log.info("  DMD API Suite Finished");
        log.info("  Suite    : {}", suite.getName());
        log.info("  Total    : {} | Passed: {} | Failed: {} | Skipped: {}", total, p, f, s);
        log.info("  Pass Rate: {}%", total > 0 ? String.format("%.1f", p * 100.0 / total) : "N/A");
        log.info("  Report   : target/extent-reports/SparkReport/index.html");
        log.info("╚══════════════════════════════════════════════════════╝");

        EnvironmentConfig cfg = EnvironmentConfig.get();
        try {
            EmailReporter.sendReport(cfg.getEnv(), cfg.getMicroservice(), total, p, f, s);
        } catch (Exception e) {
            log.warn("Email report failed: {}", e.getMessage());
        }
    }
}
