package com.dmd.api.stepdefs;

import com.dmd.api.model.ScenarioContext;
import com.dmd.api.utils.ApiClient;
import com.dmd.api.utils.JsonResponseValidator;
import com.dmd.api.utils.UrlBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Step definitions for DMD JSON REST API scenarios.
 * Shares ScenarioContext with ApiStepDefs via PicoContainer DI.
 *
 * Step keyword pattern: all JSON steps start with "the JSON ..." or
 * "the client sends a JSON ..." to avoid ambiguity with XML steps.
 *
 * Base URLs are resolved per environment automatically:
 *   -Denv=stage → json.{service}.base.url from stage.properties
 *   -Denv=qa    → json.{service}.base.url from qa.properties
 *   -Denv=prod  → json.{service}.base.url from prod.properties
 */
public class JsonApiStepDefs {

    private static final Logger log = LoggerFactory.getLogger(JsonApiStepDefs.class);
    private final ScenarioContext ctx;

    public JsonApiStepDefs(ScenarioContext ctx) { this.ctx = ctx; }

    // ── GIVEN ─────────────────────────────────────────────────────────────────

    /**
     * Set JSON endpoint using a relative path.
     * Base URL is looked up from config/{env}.properties automatically.
     *
     * Example:
     *   Given the JSON API path is "/devices/359324081412299"
     *         for microservice "dmd-device-info"
     */
    @Given("the JSON API path is {string} for microservice {string}")
    public void setJsonApiPath(String path, String microservice) {
        ctx.setCurrentMicroservice(microservice);
        ctx.setCurrentUrl(UrlBuilder.buildJsonUrl(microservice, path));
        ctx.setResponseType("json");
        log.info("JSON endpoint [{}]: {}", microservice, ctx.getCurrentUrl());
    }

    /**
     * Set JSON endpoint using a complete URL (env substitution applied).
     * Use when full URLs are hardcoded in the feature file pointing at prod.
     */
    @Given("the JSON API endpoint is {string} for microservice {string}")
    public void setJsonApiFullUrl(String url, String microservice) {
        ctx.setCurrentMicroservice(microservice);
        ctx.setCurrentUrl(UrlBuilder.toEnvJsonUrl(url, microservice));
        ctx.setResponseType("json");
        log.info("JSON endpoint (full) [{}]: {}", microservice, ctx.getCurrentUrl());
    }

    @Given("the JSON request body is:")
    public void setJsonRequestBody(String body) { ctx.setJsonRequestBody(body); }

    @Given("the request uses bearer token {string}")
    public void setBearerToken(String token) { ctx.setOverrideToken(token); }

    // ── WHEN ──────────────────────────────────────────────────────────────────

    @When("the client sends a JSON GET request")
    public void sendJsonGet() {
        String url = ctx.getCurrentUrl();
        Response r = ctx.getOverrideToken() != null
            ? ApiClient.get().jsonGetWithToken(url, ctx.getOverrideToken())
            : ApiClient.get().jsonGetFromFullUrl(url);
        ctx.setCurrentResponse(r);
        ctx.setResponseType("json");
        log.info("HTTP {} ← JSON GET {}", r.getStatusCode(), ctx.getCurrentApiName());
    }

    @When("the client sends a JSON GET request with query params:")
    public void sendJsonGetWithParams(Map<String, String> params) {
        Map<String, String> resolved = new HashMap<>();
        params.forEach((k, v) -> resolved.put(k, substituteDynamic(v)));
        String path = UrlBuilder.extractPath(ctx.getCurrentUrl());
        Response r = ApiClient.get().jsonGet(ctx.getCurrentMicroservice(), path, resolved);
        ctx.setCurrentResponse(r);
        ctx.setResponseType("json");
        log.info("HTTP {} ← JSON GET {}", r.getStatusCode(), path);
    }

    @When("the client sends a JSON POST request")
    public void sendJsonPost() {
        String body = ctx.getJsonRequestBody() != null ? ctx.getJsonRequestBody() : "{}";
        String path = UrlBuilder.extractPath(ctx.getCurrentUrl());
        Response r = ApiClient.get().jsonPost(ctx.getCurrentMicroservice(), path, body);
        ctx.setCurrentResponse(r);
        ctx.setResponseType("json");
        log.info("HTTP {} ← JSON POST {}", r.getStatusCode(), path);
    }

    // ── THEN — HTTP ───────────────────────────────────────────────────────────

    @Then("the JSON response status code should be {int}")
    public void assertJsonStatus(int expected) { jsonValidator().assertStatusCode(expected); }

    @Then("the JSON response should be successful")
    public void assertJsonSuccess() { jsonValidator().assertSuccess().assertBodyNotEmpty().assertContentTypeJson(); }

    @Then("the JSON response should be created")
    public void assertJsonCreated() { jsonValidator().assertCreated().assertBodyNotEmpty(); }

    @Then("the JSON response body should not be empty")
    public void assertJsonBodyNotEmpty() { jsonValidator().assertBodyNotEmpty(); }

    @Then("the JSON response content type should be JSON")
    public void assertContentType() { jsonValidator().assertContentTypeJson(); }

    // ── THEN — DMD ────────────────────────────────────────────────────────────

    @Then("the JSON DMD status code should be {string}")
    public void assertDmdJsonStatus(String code) { jsonValidator().assertDmdJsonStatus(code); }

    @Then("the JSON DMD response should be success")
    public void assertDmdJsonSuccess() { jsonValidator().assertDmdJsonSuccess(); }

    @Then("the JSON DMD message should be {string}")
    public void assertDmdJsonMessage(String msg) { jsonValidator().assertDmdJsonMessage(msg); }

    // ── THEN — Field presence ─────────────────────────────────────────────────

    @Then("the JSON response should contain field {string}")
    public void assertJsonFieldPresent(String path) { jsonValidator().assertFieldPresent(path); }

    @Then("the JSON response should contain fields:")
    public void assertJsonFieldsPresent(List<String> paths) { jsonValidator().assertFieldsPresent(paths); }

    @Then("the JSON field {string} should be null")
    public void assertJsonFieldNull(String path) { jsonValidator().assertFieldNull(path); }

    // ── THEN — Field value ────────────────────────────────────────────────────

    @Then("the JSON field {string} should be {string}")
    public void assertJsonFieldValue(String path, String expected) {
        jsonValidator().assertFieldValue(path, substituteDynamic(expected));
    }

    @Then("the JSON field {string} should contain {string}")
    public void assertJsonFieldContains(String path, String sub) { jsonValidator().assertFieldContains(path, sub); }

    @Then("the JSON field {string} should equal {int}")
    public void assertJsonFieldInt(String path, int expected) { jsonValidator().assertFieldEquals(path, expected); }

    @Then("the JSON field {string} should be greater than {double}")
    public void assertJsonFieldGt(String path, double min) { jsonValidator().assertFieldGreaterThan(path, min); }

    @Then("the JSON field {string} should be true")
    public void assertJsonFieldTrue(String path) { jsonValidator().assertFieldTrue(path); }

    @Then("the JSON field {string} should be false")
    public void assertJsonFieldFalse(String path) { jsonValidator().assertFieldFalse(path); }

    @Then("the JSON field {string} should match {string}")
    public void assertJsonFieldMatches(String path, String regex) { jsonValidator().assertFieldMatches(path, regex); }

    // ── THEN — Array ──────────────────────────────────────────────────────────

    @Then("the JSON array {string} should not be empty")
    public void assertJsonArrayNotEmpty(String path) { jsonValidator().assertArrayNotEmpty(path); }

    @Then("the JSON array {string} should have {int} items")
    public void assertJsonArraySize(String path, int size) { jsonValidator().assertArraySize(path, size); }

    @Then("the JSON array {string} should contain {string}")
    public void assertJsonArrayContains(String path, String value) { jsonValidator().assertArrayContains(path, value); }

    // ── THEN — Extract ────────────────────────────────────────────────────────

    @Then("I extract JSON field {string} and save it")
    public void extractJsonField(String path) {
        String value = jsonValidator().getString(path);
        ctx.setExtractedJsonValue(value);
        log.info("Extracted [{}] = {}", path, value);
    }

    @Then("the saved JSON value should be {string}")
    public void assertSavedValue(String expected) {
        assertThat(ctx.getExtractedJsonValue()).as("Saved JSON value").isEqualTo(expected);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private JsonResponseValidator jsonValidator() {
        assertThat(ctx.getCurrentResponse()).as("No JSON response captured").isNotNull();
        return new JsonResponseValidator(ctx.getCurrentResponse());
    }

    private String substituteDynamic(String v) {
        if (ctx.getDeviceId() != null) v = v.replace("${deviceId}", ctx.getDeviceId());
        if (ctx.getSimId()    != null) v = v.replace("${simId}",    ctx.getSimId());
        if (ctx.getMacId()    != null) v = v.replace("${macId}",    ctx.getMacId());
        if (ctx.getMeid()     != null) v = v.replace("${meid}",     ctx.getMeid());
        if (ctx.getAppType()  != null) v = v.replace("${appType}",  ctx.getAppType());
        if (ctx.getClientId() != null) v = v.replace("${clientId}", ctx.getClientId());
        if (ctx.getDacc()     != null) v = v.replace("${dacc}",     ctx.getDacc());
        if (ctx.getSacc()     != null) v = v.replace("${sacc}",     ctx.getSacc());
        return v;
    }
}
