package com.dmd.api.hooks;

import com.dmd.api.model.ScenarioContext;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Cucumber lifecycle hooks.
 * Before: resets ScenarioContext.
 * After:  increments pass/fail counters, attaches failure body to Extent report.
 *
 * Suite-level teardown (email dispatch) is in TestNGSuiteListener.
 */
public class CucumberHooks {

    private static final Logger log = LoggerFactory.getLogger(CucumberHooks.class);

    // Shared counters — read by TestNGSuiteListener after the suite finishes
    static final AtomicInteger passed  = new AtomicInteger(0);
    static final AtomicInteger failed  = new AtomicInteger(0);
    static final AtomicInteger skipped = new AtomicInteger(0);

    private final ScenarioContext ctx;

    public CucumberHooks(ScenarioContext ctx) { this.ctx = ctx; }

    @Before
    public void beforeScenario(Scenario scenario) {
        log.info("▶ START [{}] {}", scenario.getId(), scenario.getName());
        ctx.setCurrentResponse(null);
        ctx.setCurrentUrl(null);
        ctx.setDeviceId(null);
        ctx.setSimId(null);
        ctx.setMacId(null);
        ctx.setMeid(null);
        ctx.setAppType(null);
        ctx.setClientId(null);
        ctx.setDacc(null);
        ctx.setSacc(null);
        ctx.setJsonRequestBody(null);
        ctx.setOverrideToken(null);
        ctx.setExtractedJsonValue(null);
        ctx.setResponseType(null);
    }

    @After
    public void afterScenario(Scenario scenario) {
        if (scenario.isFailed()) {
            failed.incrementAndGet();
            if (ctx.getCurrentResponse() != null) {
                String body = ctx.getCurrentResponse().getBody().asString();
                String type = "xml".equals(ctx.getResponseType()) ? "text/xml" : "application/json";
                scenario.attach(body.getBytes(), type, "Response Body on Failure");
            }
            log.error("✗ FAILED [{}]", scenario.getName());
        } else {
            passed.incrementAndGet();
            log.info("✓ PASSED [{}]", scenario.getName());
        }
    }
}
