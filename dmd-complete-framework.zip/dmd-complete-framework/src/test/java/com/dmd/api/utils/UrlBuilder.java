package com.dmd.api.utils;

import com.dmd.api.config.EnvironmentConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Converts hardcoded prod URLs to the target environment URL at runtime.
 * Supports both XML and JSON API URL patterns.
 *
 * All feature file URLs reference prod — this class swaps the host portion
 * with whatever env is selected via -Denv=stage|qa|prod.
 */
public class UrlBuilder {

    private static final Logger log = LoggerFactory.getLogger(UrlBuilder.class);

    private static final String PROD_XML_BASE  = "https://dmdprod-awswest.verizon.com/dmd";
    private static final String PROD_JSON_BASE = "https://dmdprod-api.verizon.com";

    private UrlBuilder() {}

    // ── XML URL helpers ───────────────────────────────────────────────────────

    /** Replace prod XML host with environment-specific XML base URL. */
    public static String toEnvUrl(String url) {
        String result = url.replace(PROD_XML_BASE, EnvironmentConfig.get().getBaseUrl());
        log.debug("XML URL → {}", result.substring(0, Math.min(100, result.length())));
        return result;
    }

    /** Replace prod XML host using per-microservice base URL override. */
    public static String toEnvUrl(String url, String microservice) {
        String result = url.replace(PROD_XML_BASE, EnvironmentConfig.get().getServiceBaseUrl(microservice));
        log.debug("XML URL [{}] → {}", microservice, result.substring(0, Math.min(100, result.length())));
        return result;
    }

    // ── JSON URL helpers ──────────────────────────────────────────────────────

    /**
     * Build a full JSON API URL from microservice name + relative path.
     * Base URL is resolved from config/{env}.properties automatically.
     *
     * e.g. buildJsonUrl("dmd-device-info", "/devices/123")
     *   stage → https://dmdstage-api.verizon.com/device-info/v1/devices/123
     *   qa    → https://dmdqa-api.verizon.com/device-info/v1/devices/123
     *   prod  → https://dmdprod-api.verizon.com/device-info/v1/devices/123
     */
    public static String buildJsonUrl(String microservice, String path) {
        String base   = EnvironmentConfig.get().getJsonBaseUrl(microservice);
        String prefix = path.startsWith("/") ? "" : "/";
        String url    = base + prefix + path;
        log.debug("JSON URL [{}] → {}", microservice, url);
        return url;
    }

    /**
     * Replace prod JSON host with env-specific JSON base for a microservice.
     * Used when full JSON URLs are hardcoded in feature files pointing at prod.
     */
    public static String toEnvJsonUrl(String prodUrl, String microservice) {
        String envBase = EnvironmentConfig.get().getJsonBaseUrl(microservice);
        String path    = prodUrl.contains(PROD_JSON_BASE)
            ? prodUrl.substring(prodUrl.indexOf(PROD_JSON_BASE) + PROD_JSON_BASE.length())
            : prodUrl;
        String result  = envBase + (path.startsWith("/") ? path : "/" + path);
        log.debug("JSON URL adapted → {}", result);
        return result;
    }

    // ── Path / query helpers ──────────────────────────────────────────────────

    /** Extract path segment only (strips base URL and query string). */
    public static String extractPath(String fullUrl) {
        String stripped = fullUrl
            .replace(PROD_XML_BASE, "")
            .replace(EnvironmentConfig.get().getBaseUrl(), "");
        int q = stripped.indexOf('?');
        return q >= 0 ? stripped.substring(0, q) : stripped;
    }

    /** Parse all query parameters from URL into an ordered map. */
    public static Map<String, String> extractQueryParams(String fullUrl) {
        Map<String, String> params = new LinkedHashMap<>();
        int q = fullUrl.indexOf('?');
        if (q < 0) return params;
        for (String token : fullUrl.substring(q + 1).split("&(?![^<>]*>)")) {
            int eq = token.indexOf('=');
            if (eq <= 0) continue;
            String key = token.substring(0, eq);
            String val = token.substring(eq + 1);
            try { val = URLDecoder.decode(val, StandardCharsets.UTF_8); }
            catch (Exception ignored) {}
            params.put(key, val);
        }
        return params;
    }
}
