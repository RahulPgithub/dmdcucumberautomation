package com.dmd.api.stepdefs;

import com.dmd.api.model.ScenarioContext;
import com.dmd.api.utils.ApiClient;
import com.dmd.api.utils.UrlBuilder;
import com.dmd.api.utils.XmlResponseValidator;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Step definitions for DMD XML API scenarios.
 * PicoContainer injects ScenarioContext — fresh per scenario.
 */
public class ApiStepDefs {

    private static final Logger log = LoggerFactory.getLogger(ApiStepDefs.class);
    private final ScenarioContext ctx;

    public ApiStepDefs(ScenarioContext ctx) { this.ctx = ctx; }

    // ── GIVEN ─────────────────────────────────────────────────────────────────

    @Given("the API endpoint is {string} for microservice {string}")
    public void setApiEndpoint(String url, String microservice) {
        ctx.setCurrentMicroservice(microservice);
        ctx.setCurrentUrl(UrlBuilder.toEnvUrl(url, microservice));
        ctx.setResponseType("xml");
        log.info("XML endpoint [{}]: {}", microservice,
            ctx.getCurrentUrl().substring(0, Math.min(120, ctx.getCurrentUrl().length())));
    }

    @Given("the API name is {string}")
    public void setApiName(String name) { ctx.setCurrentApiName(name); }

    @Given("device ID is {string}")    public void setDeviceId(String v) { ctx.setDeviceId(v); }
    @Given("SIM ID is {string}")       public void setSimId(String v)    { ctx.setSimId(v); }
    @Given("MAC ID is {string}")       public void setMacId(String v)    { ctx.setMacId(v); }
    @Given("MEID is {string}")         public void setMeid(String v)     { ctx.setMeid(v); }
    @Given("app type is {string}")     public void setAppType(String v)  { ctx.setAppType(v); }
    @Given("client ID is {string}")    public void setClientId(String v) { ctx.setClientId(v); }

    // ── WHEN ──────────────────────────────────────────────────────────────────

    @When("the client sends a GET request")
    public void sendGetRequest() {
        String url = ctx.getCurrentUrl();
        log.info("GET → {}", url.substring(0, Math.min(120, url.length())));
        Response r = ApiClient.get().getFromFullUrl(url);
        ctx.setCurrentResponse(r);
        log.info("HTTP {} ← {}", r.getStatusCode(), ctx.getCurrentApiName());
    }

    @When("the client sends a GET request with parameters")
    public void sendGetWithParams() {
        Map<String, String> params = UrlBuilder.extractQueryParams(ctx.getCurrentUrl());
        params.replaceAll((k, v) -> substituteDynamic(v));
        Response r = ApiClient.get().get(UrlBuilder.extractPath(ctx.getCurrentUrl()), params);
        ctx.setCurrentResponse(r);
    }

    // ── THEN — HTTP ───────────────────────────────────────────────────────────

    @Then("the response status code should be {int}")
    public void assertStatusCode(int expected) { xmlValidator().assertStatusCode(expected); }

    @Then("the response should be successful")
    public void assertSuccess() { xmlValidator().assertSuccess().assertBodyNotEmpty(); }

    // ── THEN — DMD ────────────────────────────────────────────────────────────

    @Then("the DMD status code in response should be {string}")
    public void assertDmdStatusCode(String code) { xmlValidator().assertDmdStatusCode(code); }

    @Then("the response message should be {string}")
    public void assertMessage(String msg) { xmlValidator().assertResponseMessage(msg); }

    // ── THEN — Field ──────────────────────────────────────────────────────────

    @Then("the response should contain field {string}")
    public void assertFieldPresent(String xpath) { xmlValidator().assertFieldPresent(xpath); }

    @Then("the response should contain fields:")
    public void assertFieldsPresent(List<String> xpaths) { xmlValidator().assertFieldsPresent(xpaths); }

    @Then("the field {string} should have value {string}")
    public void assertFieldValue(String xpath, String val) { xmlValidator().assertFieldValue(xpath, val); }

    @Then("the field {string} should contain {string}")
    public void assertFieldContains(String xpath, String sub) { xmlValidator().assertFieldContains(xpath, sub); }

    @Then("the response body should not be empty")
    public void assertBodyNotEmpty() { xmlValidator().assertBodyNotEmpty(); }

    @Then("the response should contain XML element {string}")
    public void assertXmlElement(String el) { xmlValidator().assertXmlElementPresent(el); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private XmlResponseValidator xmlValidator() {
        assertThat(ctx.getCurrentResponse()).as("No response captured").isNotNull();
        return new XmlResponseValidator(ctx.getCurrentResponse());
    }

    private String substituteDynamic(String v) {
        if (ctx.getDeviceId() != null) v = v.replace("${deviceId}", ctx.getDeviceId());
        if (ctx.getSimId()    != null) v = v.replace("${simId}",    ctx.getSimId());
        if (ctx.getMacId()    != null) v = v.replace("${macId}",    ctx.getMacId());
        if (ctx.getMeid()     != null) v = v.replace("${meid}",     ctx.getMeid());
        if (ctx.getAppType()  != null) v = v.replace("${appType}",  ctx.getAppType());
        if (ctx.getClientId() != null) v = v.replace("${clientId}", ctx.getClientId());
        return v;
    }
}
