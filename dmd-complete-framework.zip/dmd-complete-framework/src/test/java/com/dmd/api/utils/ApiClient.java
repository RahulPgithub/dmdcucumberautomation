package com.dmd.api.utils;

import com.dmd.api.config.EnvironmentConfig;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

import static io.restassured.RestAssured.given;

/**
 * Central HTTP client for DMD XML and JSON APIs.
 *
 * Two distinct base specs:
 *   xmlBaseSpec  — classic DMD XML-over-HTTP pattern (no Content-Type header)
 *   jsonBaseSpec — REST JSON APIs (Accept/Content-Type: application/json, optional Bearer)
 *
 * All URLs are resolved per environment automatically via EnvironmentConfig.
 */
public class ApiClient {

    private static final Logger log = LoggerFactory.getLogger(ApiClient.class);

    private static final ApiClient INSTANCE = new ApiClient();

    private final RestAssuredConfig    raConfig;
    private final RequestSpecification xmlBaseSpec;
    private final RequestSpecification jsonBaseSpec;

    private ApiClient() {
        EnvironmentConfig cfg = EnvironmentConfig.get();

        raConfig = RestAssured.config()
            .httpClient(HttpClientConfig.httpClientConfig()
                .setParam("http.connection.timeout", cfg.getConnectionTimeout())
                .setParam("http.socket.timeout",     cfg.getReadTimeout()));

        // ── XML spec ──────────────────────────────────────────────────────────
        xmlBaseSpec = new RequestSpecBuilder()
            .setBaseUri(cfg.getBaseUrl())
            .setConfig(raConfig)
            .addFilter(new RequestLoggingFilter())
            .addFilter(new ResponseLoggingFilter())
            .build();

        // ── JSON spec ─────────────────────────────────────────────────────────
        RequestSpecBuilder jsonBuilder = new RequestSpecBuilder()
            .setConfig(raConfig)
            .setContentType(ContentType.JSON)
            .setAccept(ContentType.JSON)
            .addFilter(new RequestLoggingFilter())
            .addFilter(new ResponseLoggingFilter());

        if (cfg.isJsonAuthEnabled()) {
            String token = cfg.getJsonAuthToken();
            if (token != null && !token.isBlank() && !token.endsWith("_TOKEN_HERE")) {
                jsonBuilder.addHeader("Authorization", "Bearer " + token);
                log.info("JSON auth: Bearer token attached (env={})", cfg.getEnv());
            } else {
                log.warn("JSON auth enabled but token not configured for env='{}'", cfg.getEnv());
            }
        }

        jsonBaseSpec = jsonBuilder.build();
        log.info("ApiClient ready — env={} | xmlBase={}", cfg.getEnv(), cfg.getBaseUrl());
    }

    public static ApiClient get() { return INSTANCE; }

    // ════════════════════════════════════════════════════════════
    //  XML API methods
    // ════════════════════════════════════════════════════════════

    /** GET with query params map (XML API). */
    public Response get(String path, Map<String, String> queryParams) {
        RequestSpecification spec = given().spec(xmlBaseSpec);
        if (queryParams != null && !queryParams.isEmpty()) {
            spec.queryParams(queryParams);
        }
        return spec.when().get(path).then().extract().response();
    }

    /**
     * GET using a fully-qualified URL.
     * Used for DMD XML APIs where the XML payload is embedded in the URL.
     */
    public Response getFromFullUrl(String fullUrl) {
        return given()
            .config(raConfig)
            .filter(new RequestLoggingFilter())
            .filter(new ResponseLoggingFilter())
            .when().get(fullUrl)
            .then().extract().response();
    }

    // ════════════════════════════════════════════════════════════
    //  JSON API methods
    // ════════════════════════════════════════════════════════════

    /**
     * JSON GET — resolves base URL from microservice name.
     * e.g. jsonGet("dmd-device-info", "/devices/123")
     */
    public Response jsonGet(String microservice, String path) {
        String url = UrlBuilder.buildJsonUrl(microservice, path);
        log.info("JSON GET → {}", url);
        return given().spec(jsonBaseSpec).when().get(url).then().extract().response();
    }

    /** JSON GET with query parameters. */
    public Response jsonGet(String microservice, String path, Map<String, String> queryParams) {
        String url  = UrlBuilder.buildJsonUrl(microservice, path);
        RequestSpecification spec = given().spec(jsonBaseSpec);
        if (queryParams != null && !queryParams.isEmpty()) {
            spec.queryParams(queryParams);
        }
        return spec.when().get(url).then().extract().response();
    }

    /** JSON GET using a complete pre-built URL. */
    public Response jsonGetFromFullUrl(String fullUrl) {
        log.info("JSON GET → {}", fullUrl);
        return given().spec(jsonBaseSpec).when().get(fullUrl).then().extract().response();
    }

    /** JSON GET with a per-request Bearer token override. */
    public Response jsonGetWithToken(String fullUrl, String bearerToken) {
        return given().spec(jsonBaseSpec)
            .header("Authorization", "Bearer " + bearerToken)
            .when().get(fullUrl)
            .then().extract().response();
    }

    /** JSON POST with a body. */
    public Response jsonPost(String microservice, String path, String jsonBody) {
        String url = UrlBuilder.buildJsonUrl(microservice, path);
        log.info("JSON POST → {}", url);
        return given().spec(jsonBaseSpec)
            .body(jsonBody)
            .when().post(url)
            .then().extract().response();
    }
}
