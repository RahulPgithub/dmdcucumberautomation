package com.dmd.api.utils;

import io.restassured.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

/**
 * Fluent validator for XML API responses.
 * Uses javax XPath for field navigation.
 *
 * Supported checks:
 *   HTTP status, DMD statusCode (//statusCode), field presence,
 *   field value equality/contains, body not-empty, XML element check.
 */
public class XmlResponseValidator {

    private static final Logger log = LoggerFactory.getLogger(XmlResponseValidator.class);

    private final Response response;
    private Document document;

    public XmlResponseValidator(Response response) {
        this.response = response;
        parseDocument();
    }

    private void parseDocument() {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(false);
            dbf.setValidating(false);
            dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            document = dbf.newDocumentBuilder()
                .parse(new InputSource(new StringReader(response.getBody().asString())));
        } catch (Exception e) {
            log.warn("Response is not valid XML: {}", e.getMessage());
            document = null;
        }
    }

    // ── HTTP ──────────────────────────────────────────────────────────────────
    public XmlResponseValidator assertStatusCode(int expected) {
        assertThat(response.getStatusCode()).as("HTTP Status Code").isEqualTo(expected);
        return this;
    }
    public XmlResponseValidator assertSuccess()      { return assertStatusCode(200); }
    public XmlResponseValidator assertBodyNotEmpty() {
        assertThat(response.getBody().asString()).as("Response body").isNotNull().isNotBlank();
        return this;
    }

    // ── DMD business code ─────────────────────────────────────────────────────
    public XmlResponseValidator assertDmdStatusCode(String code) {
        assertThat(xpathValue("//statusCode")).as("DMD <statusCode>").isEqualTo(code);
        return this;
    }
    public XmlResponseValidator assertResponseMessage(String msg) {
        return assertFieldValue("//message", msg);
    }

    // ── Field presence ────────────────────────────────────────────────────────
    public XmlResponseValidator assertFieldPresent(String xpath) {
        String v = xpathValue(xpath);
        assertThat(v).as("Field at XPath [%s]", xpath).isNotNull().isNotBlank();
        return this;
    }
    public XmlResponseValidator assertFieldsPresent(List<String> xpaths) {
        xpaths.forEach(this::assertFieldPresent);
        return this;
    }

    // ── Field value ───────────────────────────────────────────────────────────
    public XmlResponseValidator assertFieldValue(String xpath, String expected) {
        assertThat(xpathValue(xpath)).as("Value at XPath [%s]", xpath).isEqualTo(expected);
        return this;
    }
    public XmlResponseValidator assertFieldContains(String xpath, String sub) {
        assertThat(xpathValue(xpath)).as("XPath [%s] contains", xpath).contains(sub);
        return this;
    }
    public XmlResponseValidator assertXmlElementPresent(String element) {
        assertThat(response.getBody().asString()).as("XML element <%s>", element).contains("<" + element);
        return this;
    }

    // ── Accessor ──────────────────────────────────────────────────────────────
    public String xpathValue(String xpath) {
        if (document == null) fail("Not valid XML. Body: " + response.getBody().asString());
        try {
            XPath xp = XPathFactory.newInstance().newXPath();
            return (String) xp.evaluate(xpath, document, XPathConstants.STRING);
        } catch (Exception e) {
            log.error("XPath error [{}]: {}", xpath, e.getMessage());
            return null;
        }
    }
    public int      getHttpStatusCode() { return response.getStatusCode(); }
    public String   getRawBody()        { return response.getBody().asString(); }
    public Response getResponse()       { return response; }
}
