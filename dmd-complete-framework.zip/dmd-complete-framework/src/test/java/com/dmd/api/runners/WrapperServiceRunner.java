package com.dmd.api.runners;

import io.cucumber.testng.CucumberOptions;

/** Runner for dmd-wrapper-service (XML + JSON). */
@CucumberOptions(
    features   = "src/test/resources/features/dmd-wrapper-service",
    glue       = {"com.dmd.api.stepdefs", "com.dmd.api.hooks"},
    plugin     = {
        "pretty",
        "json:target/cucumber-reports/dmd-wrapper-service.json",
        "html:target/cucumber-reports/dmd-wrapper-service.html",
        "tech.grasshopper.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
    },
    monochrome = true,
    publish    = false
)
public class WrapperServiceRunner extends AbstractCucumberRunner {}
