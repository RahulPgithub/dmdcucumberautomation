package com.dmd.api.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import org.testng.annotations.DataProvider;

/**
 * Base class for all DMD microservice runners.
 * Extends AbstractTestNGCucumberTests — the TestNG equivalent of JUnit 5 @Suite.
 * Each subclass declares @CucumberOptions pointing at its features folder.
 */
public abstract class AbstractCucumberRunner extends AbstractTestNGCucumberTests {

    @Override
    @DataProvider(parallel = false)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
