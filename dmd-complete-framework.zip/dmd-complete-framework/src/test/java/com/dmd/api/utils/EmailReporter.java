package com.dmd.api.utils;

import com.dmd.api.config.EnvironmentConfig;
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.HtmlEmail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Sends an HTML email with test results summary + Extent report attached.
 * Called by TestNGSuiteListener after the suite finishes.
 * SMTP credentials come from EMAIL_USER / EMAIL_PASS environment variables.
 */
public class EmailReporter {

    private static final Logger log = LoggerFactory.getLogger(EmailReporter.class);
    private EmailReporter() {}

    public static void sendReport(String env, String microservice,
                                  int total, int passed, int failed, int skipped) {
        EnvironmentConfig cfg = EnvironmentConfig.get();
        if (cfg.getEmailSmtpHost().isBlank()) {
            log.info("SMTP host not configured — skipping email report.");
            return;
        }
        try {
            HtmlEmail email = new HtmlEmail();
            email.setHostName(cfg.getEmailSmtpHost());
            email.setSmtpPort(cfg.getEmailSmtpPort());

            String user = System.getenv("EMAIL_USER");
            String pass = System.getenv("EMAIL_PASS");
            if (user != null && pass != null) {
                email.setAuthenticator(new DefaultAuthenticator(user, pass));
                email.setStartTLSEnabled(true);
            }

            email.setFrom(cfg.getEmailFrom());
            for (String to : cfg.getEmailTo()) {
                if (!to.isBlank()) email.addTo(to.trim());
            }

            String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
            email.setSubject(String.format("%s | %s | %s | P:%d F:%d",
                cfg.getEmailSubjectPrefix(), microservice, ts, passed, failed));
            email.setHtmlMsg(buildHtml(env, microservice, total, passed, failed, skipped, ts));
            email.setTextMsg("DMD API Tests " + ts + " | Total:" + total +
                " Passed:" + passed + " Failed:" + failed);

            attachIfExists(email, cfg.getReportDir() + "/SparkReport/index.html", "Extent-Report.html");
            email.send();
            log.info("Email report sent to: {}", String.join(", ", cfg.getEmailTo()));

        } catch (Exception e) {
            log.error("Email report failed: {}", e.getMessage(), e);
        }
    }

    private static void attachIfExists(HtmlEmail email, String path, String name) {
        File f = new File(path);
        if (!f.exists()) return;
        try {
            EmailAttachment att = new EmailAttachment();
            att.setPath(path);
            att.setDisposition(EmailAttachment.ATTACHMENT);
            att.setName(name);
            email.attach(att);
        } catch (Exception e) {
            log.warn("Could not attach report: {}", e.getMessage());
        }
    }

    private static String buildHtml(String env, String svc, int total,
                                    int p, int f, int s, String ts) {
        double rate  = total > 0 ? p * 100.0 / total : 0;
        String color = f > 0 ? "#e74c3c" : "#27ae60";
        String status = f > 0 ? "FAILED" : "PASSED";
        return "<html><body style='font-family:Arial,sans-serif;padding:24px'>"
            + "<h2 style='color:" + color + "'>DMD API Suite: " + status + "</h2>"
            + "<table cellpadding='9' style='border-collapse:collapse;width:520px;border:1px solid #ddd'>"
            + row("Environment",  env.toUpperCase()) + row("Microservice", svc)
            + row("Timestamp",    ts)
            + row("Total",        String.valueOf(total))
            + row("Passed",  "<b style='color:#27ae60'>" + p + "</b>")
            + row("Failed",  "<b style='color:#e74c3c'>" + f + "</b>")
            + row("Skipped", String.valueOf(s))
            + row("Pass Rate", String.format("%.1f%%", rate))
            + "</table><p style='color:#888;font-size:12px'>Extent report attached.</p>"
            + "</body></html>";
    }

    private static String row(String l, String v) {
        return "<tr style='border-bottom:1px solid #eee'>"
            + "<td style='font-weight:bold;color:#555;width:160px'>" + l + "</td>"
            + "<td>" + v + "</td></tr>";
    }
}
