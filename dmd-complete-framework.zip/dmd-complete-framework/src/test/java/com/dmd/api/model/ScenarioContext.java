package com.dmd.api.model;

import io.restassured.response.Response;
import lombok.Data;

/**
 * Shared per-scenario state injected via Cucumber PicoContainer DI.
 * A new instance is created for every scenario — zero cross-scenario leakage.
 * Supports both XML and JSON API test scenarios.
 */
@Data
public class ScenarioContext {

    // ── Request ───────────────────────────────────────────────────────────────
    private String   currentUrl;
    private String   currentApiName;
    private String   currentMicroservice;
    private String   responseType;        // "xml" | "json"

    // ── Response ──────────────────────────────────────────────────────────────
    private Response currentResponse;

    // ── Dynamic data (XML and JSON scenarios) ────────────────────────────────
    private String deviceId;
    private String simId;
    private String macId;
    private String meid;
    private String appType;
    private String clientId;
    private String dacc;
    private String sacc;

    // ── JSON-specific ─────────────────────────────────────────────────────────
    private String jsonRequestBody;       // POST body
    private String extractedJsonValue;    // value saved from a previous step
    private String overrideToken;         // per-scenario Bearer token
}
