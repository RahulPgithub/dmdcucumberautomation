package com.dmd.api.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Singleton that loads environment-specific config at startup.
 * Controlled by JVM system property: -Denv=stage|qa|prod  (default: stage)
 *
 * Each environment config carries:
 *   - XML API base URL (per-service overrides supported)
 *   - JSON REST API base URL per microservice
 *   - Auth settings for JSON APIs (Bearer token / OAuth)
 *   - Email and report settings
 */
public class EnvironmentConfig {

    private static final Logger log = LoggerFactory.getLogger(EnvironmentConfig.class);

    private static final EnvironmentConfig INSTANCE = new EnvironmentConfig();
    private final Properties props = new Properties();
    private final String env;

    private EnvironmentConfig() {
        env = System.getProperty("env", "stage").toLowerCase().trim();
        String configFile = "config/" + env + ".properties";
        log.info("Loading environment config: {}", configFile);
        try (InputStream is = getClass().getClassLoader().getResourceAsStream(configFile)) {
            if (is == null) {
                throw new RuntimeException(
                    "Config file not found: " + configFile +
                    " — valid values: stage, qa, prod");
            }
            props.load(is);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load config: " + configFile, e);
        }
        log.info("Env={} | XML base={}", env, getBaseUrl());
    }

    public static EnvironmentConfig get() { return INSTANCE; }

    // ── Identity ──────────────────────────────────────────────────────────────
    public String  getEnv()     { return env; }
    public boolean isStage()    { return "stage".equals(env); }
    public boolean isQa()       { return "qa".equals(env); }
    public boolean isProd()     { return "prod".equals(env); }

    // ── XML API URLs ──────────────────────────────────────────────────────────

    /** Default XML base URL for all services. */
    public String getBaseUrl() {
        return props.getProperty("base.url");
    }

    /**
     * Per-microservice XML base URL.
     * Falls back to getBaseUrl() if no override is set.
     */
    public String getServiceBaseUrl(String microservice) {
        return props.getProperty("service." + microservice + ".base.url", getBaseUrl());
    }

    // ── JSON API URLs ─────────────────────────────────────────────────────────

    /**
     * JSON REST base URL for a microservice.
     * Configured as: json.{microservice}.base.url in properties file.
     * Falls back to XML base URL if not configured.
     */
    public String getJsonBaseUrl(String microservice) {
        String key = "json." + microservice + ".base.url";
        String url = props.getProperty(key);
        if (url == null || url.isBlank()) {
            log.warn("No JSON base URL for '{}' in {} — add 'json.{}.base.url' to config/{}.properties",
                microservice, env, microservice, env);
            return getBaseUrl();
        }
        return url;
    }

    // ── JSON Auth ─────────────────────────────────────────────────────────────
    public boolean isJsonAuthEnabled()   { return Boolean.parseBoolean(props.getProperty("json.auth.enabled", "false")); }
    public String  getJsonAuthToken()    { return props.getProperty("json.auth.token", ""); }
    public String  getJsonAuthClientId() { return props.getProperty("json.auth.client.id", ""); }
    public String  getJsonAuthTokenUrl() { return props.getProperty("json.auth.token.url", ""); }

    // ── Timeouts ──────────────────────────────────────────────────────────────
    public int getConnectionTimeout() { return intProp("connection.timeout", 30000); }
    public int getReadTimeout()       { return intProp("read.timeout", 60000); }

    // ── Email ─────────────────────────────────────────────────────────────────
    public String   getEmailSmtpHost()      { return props.getProperty("email.smtp.host", ""); }
    public int      getEmailSmtpPort()      { return intProp("email.smtp.port", 587); }
    public String   getEmailFrom()          { return props.getProperty("email.from", ""); }
    public String[] getEmailTo()            { return props.getProperty("email.to", "").split(","); }
    public String   getEmailSubjectPrefix() { return props.getProperty("email.subject.prefix", "[DMD]"); }

    // ── Reports ───────────────────────────────────────────────────────────────
    public String getReportDir()    { return props.getProperty("report.dir", "target/extent-reports"); }
    public String getMicroservice() { return System.getProperty("microservice", "all"); }

    // ── Helper ────────────────────────────────────────────────────────────────
    private int intProp(String key, int def) {
        try { return Integer.parseInt(props.getProperty(key, String.valueOf(def))); }
        catch (NumberFormatException e) { return def; }
    }
}
