package com.dmd.api.runners;

import io.cucumber.testng.CucumberOptions;

/**
 * Master runner — all microservices, XML + JSON features.
 * Usage: mvn test -Denv=stage|qa|prod
 */
@CucumberOptions(
    features   = "src/test/resources/features",
    glue       = {"com.dmd.api.stepdefs", "com.dmd.api.hooks"},
    plugin     = {
        "pretty",
        "json:target/cucumber-reports/all-services.json",
        "html:target/cucumber-reports/all-services.html",
        "tech.grasshopper.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
    },
    monochrome = true,
    publish    = false
)
public class AllServicesRunner extends AbstractCucumberRunner {}
