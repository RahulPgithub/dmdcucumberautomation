package com.dmd.api.runners;

import io.cucumber.testng.CucumberOptions;

/** Runner for dmd-device-info (XML + JSON). */
@CucumberOptions(
    features   = "src/test/resources/features/dmd-device-info",
    glue       = {"com.dmd.api.stepdefs", "com.dmd.api.hooks"},
    plugin     = {
        "pretty",
        "json:target/cucumber-reports/dmd-device-info.json",
        "html:target/cucumber-reports/dmd-device-info.html",
        "tech.grasshopper.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
    },
    monochrome = true,
    publish    = false
)
public class DeviceInfoRunner extends AbstractCucumberRunner {}
