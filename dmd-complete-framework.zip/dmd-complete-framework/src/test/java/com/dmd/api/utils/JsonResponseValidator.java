package com.dmd.api.utils;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

/**
 * Fluent validator for JSON REST API responses.
 * Uses REST Assured JsonPath for field navigation.
 *
 * Supported checks:
 * ┌──────────────────────────────────────────────────────────────────┐
 * │  HTTP      : statusCode, body not empty, content-type           │
 * │  Presence  : field present/null, list of fields                 │
 * │  Value     : string equals/contains/matches, int, double, bool  │
 * │  Array     : not empty, size, contains value                    │
 * │  DMD JSON  : statusCode, message (auto-probes multiple paths)   │
 * └──────────────────────────────────────────────────────────────────┘
 */
public class JsonResponseValidator {

    private static final Logger log = LoggerFactory.getLogger(JsonResponseValidator.class);

    private final Response response;
    private final JsonPath jsonPath;

    public JsonResponseValidator(Response response) {
        this.response = response;
        JsonPath jp = null;
        try {
            jp = response.jsonPath();
        } catch (Exception e) {
            log.warn("Response is not valid JSON: {} | Body snippet: {}",
                e.getMessage(),
                response.getBody().asString().substring(
                    0, Math.min(200, response.getBody().asString().length())));
        }
        this.jsonPath = jp;
    }

    // ── HTTP ──────────────────────────────────────────────────────────────────
    public JsonResponseValidator assertStatusCode(int expected) {
        assertThat(response.getStatusCode()).as("HTTP Status Code").isEqualTo(expected);
        return this;
    }
    public JsonResponseValidator assertSuccess()      { return assertStatusCode(200); }
    public JsonResponseValidator assertCreated()      { return assertStatusCode(201); }
    public JsonResponseValidator assertBadRequest()   { return assertStatusCode(400); }
    public JsonResponseValidator assertUnauthorized() { return assertStatusCode(401); }
    public JsonResponseValidator assertNotFound()     { return assertStatusCode(404); }

    public JsonResponseValidator assertBodyNotEmpty() {
        assertThat(response.getBody().asString()).as("Response body").isNotNull().isNotBlank();
        return this;
    }
    public JsonResponseValidator assertContentTypeJson() {
        assertThat(response.getContentType()).as("Content-Type").containsIgnoringCase("application/json");
        return this;
    }

    // ── Field presence ────────────────────────────────────────────────────────
    public JsonResponseValidator assertFieldPresent(String path) {
        requireJson(path);
        Object v = jsonPath.get(path);
        assertThat(v).as("Field present at [%s]", path).isNotNull();
        if (v instanceof String) assertThat((String) v).as("Field non-blank at [%s]", path).isNotBlank();
        return this;
    }
    public JsonResponseValidator assertFieldsPresent(List<String> paths) {
        paths.forEach(this::assertFieldPresent);
        return this;
    }
    public JsonResponseValidator assertFieldNull(String path) {
        requireJson(path);
        assertThat(jsonPath.get(path)).as("Field null at [%s]", path).isNull();
        return this;
    }

    // ── Field value — String ──────────────────────────────────────────────────
    public JsonResponseValidator assertFieldValue(String path, String expected) {
        requireJson(path);
        assertThat(jsonPath.getString(path)).as("Value at [%s]", path).isEqualTo(expected);
        return this;
    }
    public JsonResponseValidator assertFieldContains(String path, String sub) {
        requireJson(path);
        assertThat(jsonPath.getString(path)).as("[%s] contains", path).contains(sub);
        return this;
    }
    public JsonResponseValidator assertFieldMatches(String path, String regex) {
        requireJson(path);
        assertThat(jsonPath.getString(path)).as("[%s] matches regex", path).matches(regex);
        return this;
    }

    // ── Field value — Numeric ─────────────────────────────────────────────────
    public JsonResponseValidator assertFieldEquals(String path, int expected) {
        requireJson(path);
        assertThat(jsonPath.getInt(path)).as("Int at [%s]", path).isEqualTo(expected);
        return this;
    }
    public JsonResponseValidator assertFieldGreaterThan(String path, double min) {
        requireJson(path);
        assertThat(jsonPath.getDouble(path)).as("[%s] > %s", path, min).isGreaterThan(min);
        return this;
    }

    // ── Field value — Boolean ─────────────────────────────────────────────────
    public JsonResponseValidator assertFieldTrue(String path) {
        requireJson(path);
        assertThat(jsonPath.getBoolean(path)).as("Boolean at [%s]", path).isTrue();
        return this;
    }
    public JsonResponseValidator assertFieldFalse(String path) {
        requireJson(path);
        assertThat(jsonPath.getBoolean(path)).as("Boolean at [%s]", path).isFalse();
        return this;
    }

    // ── Array ─────────────────────────────────────────────────────────────────
    public JsonResponseValidator assertArrayNotEmpty(String path) {
        requireJson(path);
        assertThat(jsonPath.getList(path)).as("Array at [%s]", path).isNotNull().isNotEmpty();
        return this;
    }
    public JsonResponseValidator assertArraySize(String path, int size) {
        requireJson(path);
        assertThat(jsonPath.getList(path)).as("Array size at [%s]", path).hasSize(size);
        return this;
    }
    public JsonResponseValidator assertArrayContains(String path, String value) {
        requireJson(path);
        assertThat(jsonPath.getList(path, String.class)).as("Array [%s] contains", path).contains(value);
        return this;
    }

    // ── DMD JSON business logic ───────────────────────────────────────────────

    /**
     * Assert DMD JSON statusCode. Probes multiple common paths:
     * statusCode → responseHeader.statusCode → response.statusCode
     */
    public JsonResponseValidator assertDmdJsonStatus(String expected) {
        requireJson("statusCode");
        String actual = jsonPath.getString("statusCode");
        if (actual == null) actual = jsonPath.getString("responseHeader.statusCode");
        if (actual == null) actual = jsonPath.getString("response.statusCode");
        assertThat(actual).as("DMD JSON statusCode").isEqualTo(expected);
        return this;
    }
    public JsonResponseValidator assertDmdJsonSuccess() { return assertDmdJsonStatus("00"); }

    /** Assert DMD JSON message. Probes: message → responseHeader.message → response.message */
    public JsonResponseValidator assertDmdJsonMessage(String expected) {
        requireJson("message");
        String actual = jsonPath.getString("message");
        if (actual == null) actual = jsonPath.getString("responseHeader.message");
        if (actual == null) actual = jsonPath.getString("response.message");
        assertThat(actual).as("DMD JSON message").isEqualTo(expected);
        return this;
    }

    // ── Accessors ─────────────────────────────────────────────────────────────
    public String           getString(String path) { requireJson(path); return jsonPath.getString(path); }
    public int              getInt(String path)    { requireJson(path); return jsonPath.getInt(path); }
    public <T> List<T>      getList(String path, Class<T> type) { requireJson(path); return jsonPath.getList(path, type); }
    public Map<String, Object> asMap()             { requireJson("$"); return response.jsonPath().getMap("$"); }
    public int              getHttpStatusCode()    { return response.getStatusCode(); }
    public String           getRawBody()           { return response.getBody().asString(); }
    public Response         getResponse()          { return response; }

    // ── Internal ──────────────────────────────────────────────────────────────
    private void requireJson(String ctx) {
        if (jsonPath == null) fail("Not valid JSON at [" + ctx + "]. Status=" +
            response.getStatusCode() + " Body=" +
            response.getBody().asString().substring(
                0, Math.min(500, response.getBody().asString().length())));
    }
}
