package com.dmd.api.listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.dmd.api.config.EnvironmentConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;

/**
 * TestNG ITestListener that maintains a standalone Extent TestNG report
 * alongside the Cucumber adapter Spark report.
 *
 * Spark (Cucumber):  target/extent-reports/SparkReport/index.html
 * TestNG report:     target/extent-reports/TestNGReport/index.html
 */
public class ExtentTestNGReportListener implements ITestListener {

    private static final Logger log = LoggerFactory.getLogger(ExtentTestNGReportListener.class);

    private static ExtentReports                 extent    = null;
    private static final ThreadLocal<ExtentTest> testLocal = new ThreadLocal<>();

    @Override
    public void onStart(ITestContext context) {
        EnvironmentConfig cfg = EnvironmentConfig.get();
        String reportPath = cfg.getReportDir() + "/TestNGReport/index.html";
        new File(cfg.getReportDir() + "/TestNGReport").mkdirs();

        ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);
        spark.config().setDocumentTitle("DMD API TestNG Report");
        spark.config().setReportName(
            "DMD API — " + cfg.getEnv().toUpperCase() + " | " + cfg.getMicroservice());
        spark.config().setTheme(Theme.DARK);
        spark.config().setEncoding("UTF-8");

        extent = new ExtentReports();
        extent.attachReporter(spark);
        extent.setSystemInfo("Environment",  cfg.getEnv().toUpperCase());
        extent.setSystemInfo("Microservice", cfg.getMicroservice());
        extent.setSystemInfo("BaseURL",      cfg.getBaseUrl());
        extent.setSystemInfo("Build",        System.getProperty("build.number", "local"));
        log.info("ExtentReports initialised → {}", reportPath);
    }

    @Override
    public void onTestStart(ITestResult result) {
        testLocal.set(extent.createTest(result.getTestClass().getName() + " :: " + result.getName()));
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        testLocal.get().pass("Passed");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        Throwable t = result.getThrowable();
        testLocal.get().fail(t != null ? t : new RuntimeException("Test failed — no throwable"));
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        testLocal.get().skip("Skipped");
    }

    @Override
    public void onFinish(ITestContext context) {
        if (extent != null) {
            extent.flush();
            log.info("TestNG Extent report flushed → {}/TestNGReport/index.html",
                EnvironmentConfig.get().getReportDir());
        }
        testLocal.remove();
    }
}
