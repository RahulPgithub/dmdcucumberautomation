
Feature: Execute APIs from Excel

Scenario: Run all APIs
  Given Load API data from Excel
  When Execute APIs for "ALL"
  Then Generate report
