
package services;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import java.util.Map;

public class RequestExecutor {

 public static Response execute(Map<String,String> row){
  String fullUrl=row.get("Request");

  return RestAssured.given()
    .relaxedHTTPSValidation()
    .get(fullUrl);
 }
}
