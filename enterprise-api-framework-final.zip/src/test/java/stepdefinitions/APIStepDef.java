
package stepdefinitions;

import io.cucumber.java.en.*;
import utils.*;
import services.*;

import java.util.*;

public class APIStepDef {

 List<Map<String,String>> data;
 List<Map<String,String>> results=new ArrayList<>();

 @Given("Load API data from Excel")
 public void load(){
  data=ExcelReader.getData("src/test/resources/testdata/api-data.xlsx");
 }

 @When("Execute APIs for {string}")
 public void execute(String service){

  for(Map<String,String> row:data){

   if(!service.equals("ALL") &&
   !row.get("MicroServices Type").equalsIgnoreCase(service)) continue;

   var res=RequestExecutor.execute(row);

   String result=res.asString().contains("responseHeader")?"PASS":"FAIL";

   row.put("STATUS",result);
   row.put("ActualStatus",String.valueOf(res.getStatusCode()));

   LoggerUtil.info("API: "+row.get("API name"));
   LoggerUtil.info("Response: "+res.asString());

   results.add(row);
  }
 }

 @Then("Generate report")
 public void report(){
  System.out.println("Execution Completed");
 }
}
