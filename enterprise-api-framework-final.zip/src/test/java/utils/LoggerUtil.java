
package utils;

import org.apache.logging.log4j.*;

public class LoggerUtil {
 private static final Logger log = LogManager.getLogger();

 public static void info(String msg){
  log.info(msg);
 }
}
