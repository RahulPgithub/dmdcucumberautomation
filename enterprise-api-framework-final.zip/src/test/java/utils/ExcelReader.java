
package utils;

import org.apache.poi.xssf.usermodel.*;
import java.io.File;
import java.util.*;

public class ExcelReader {

 public static List<Map<String,String>> getData(String path){
  List<Map<String,String>> list=new ArrayList<>();

  try{
   XSSFWorkbook wb=new XSSFWorkbook(new File(path));
   XSSFSheet sheet=wb.getSheetAt(0);
   XSSFRow header=sheet.getRow(0);

   for(int i=1;i<=sheet.getLastRowNum();i++){
    Map<String,String> map=new HashMap<>();
    for(int j=0;j<header.getLastCellNum();j++){
     map.put(header.getCell(j).toString(),
     sheet.getRow(i).getCell(j).toString());
    }
    list.add(map);
   }
  }catch(Exception e){throw new RuntimeException(e);}
  return list;
 }
}
